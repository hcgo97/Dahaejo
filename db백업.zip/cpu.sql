--------------------------------------------------------
--  ������ ������ - ������-11��-30-2020   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Table CPU
--------------------------------------------------------

  CREATE TABLE "SCOTT"."CPU" 
   (	"NAME" VARCHAR2(50 BYTE), 
	"PRICE" NUMBER, 
	"LINK" VARCHAR2(1000 BYTE), 
	"COMPANY" VARCHAR2(50 BYTE)
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
REM INSERTING into SCOTT.CPU
SET DEFINE OFF;
Insert into SCOTT.CPU (NAME,PRICE,LINK,COMPANY) values ('Ŀ�Ƿ���ũ-g4930',37850,'https://search.shopping.naver.com/catalog/20968502643?query=G4930&NaPm=ct%3Dkhyla6uw%7Cci%3Dc03cdba2770b05c42a02f5838bd1eb24c7107acc%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3D4f2b809101a0fe05d1c07703d19157203e82baad','����');
Insert into SCOTT.CPU (NAME,PRICE,LINK,COMPANY) values ('r5-3400g',152480,'https://search.shopping.naver.com/catalog/20071591863?query=%EB%9D%BC%EC%9D%B4%EC%A0%A05%203400G&NaPm=ct%3Dkhyldfdc%7Cci%3De9bfc2a9985cf70fc0cfb417269dc7ac5eb90d53%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3De9ca2186311c0609dc6f9b220f3177e2e1873a4e','AMD');
Insert into SCOTT.CPU (NAME,PRICE,LINK,COMPANY) values ('i3-10100',140300,'https://search.shopping.naver.com/catalog/24040936528?query=%EC%BD%94%EB%A9%A7%20i3%2010100&NaPm=ct%3Dkhylfi7s%7Cci%3D944648cddba6eb0f8caf0c9998d337241704ad3f%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3Deff2e414a0f041e2a1c4fcc29a44eee3e80de014','����');
Insert into SCOTT.CPU (NAME,PRICE,LINK,COMPANY) values ('r3-3200g',111270,'https://search.shopping.naver.com/catalog/20071591864?query=%EB%9D%BC%EC%9D%B4%EC%A0%A03%203200G&NaPm=ct%3Dkhylhdcg%7Cci%3D3c93dcd71b395170f33bd007680fe013e8e2dcab%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3D42338e922c68f17709ad62ead5f76be75a49ff2d','AMD');
Insert into SCOTT.CPU (NAME,PRICE,LINK,COMPANY) values ('�ڸ�-g5905',43000,'https://search.shopping.naver.com/search/all?query=%EC%BD%94%EB%A9%A7%20G5905&frm=NVSHATC','����');
Insert into SCOTT.CPU (NAME,PRICE,LINK,COMPANY) values ('i9-9980xe',1160200,'https://search.shopping.naver.com/catalog/19276664902?query=%20i9-9980XE&NaPm=ct%3Dkhyshdvk%7Cci%3D48e7730935758bbea625c87e2b6bedb899ae7db3%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3Da7883c04a4061312ad6322ed39dd44b8e045251b','��ī�̷���ũ');
Insert into SCOTT.CPU (NAME,PRICE,LINK,COMPANY) values ('i9-9960x',1377730,'https://search.shopping.naver.com/search/all?query=i9-9960X&frm=NVSHATC&prevQuery=%20i9-9980XE','����');
Insert into SCOTT.CPU (NAME,PRICE,LINK,COMPANY) values ('i9-10940x',947520,'https://search.shopping.naver.com/catalog/21708077246?query=i9-10940X&NaPm=ct%3Dkhysjdmw%7Cci%3D8b6e505abc00b1f1e96f7da26f01e9ebef353e6f%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3D3b5d5e59cfafef411a614f62adb9fe74885ec321','����');
Insert into SCOTT.CPU (NAME,PRICE,LINK,COMPANY) values ('i9-7980xe',2534330,'https://search.shopping.naver.com/catalog/13146082708?query=i9-7980XE&NaPm=ct%3Dkhysk8i0%7Cci%3D76db897fd5bbafcb089849e4316e017df846e565%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3Ddbf875b0773ca0aeec87a558864db2f2e737f40b','����');
Insert into SCOTT.CPU (NAME,PRICE,LINK,COMPANY) values ('i9-9940x',1113780,'https://search.shopping.naver.com/search/all?query=i9-9940X&frm=NVSHATC&prevQuery=Gold%206254','����');
Insert into SCOTT.CPU (NAME,PRICE,LINK,COMPANY) values ('i9-7960x',1724800,'https://search.shopping.naver.com/search/all?query=i9-7960X&frm=NVSHATC&prevQuery=i9-9940X','����');
Insert into SCOTT.CPU (NAME,PRICE,LINK,COMPANY) values ('i9-10920x',834520,'https://search.shopping.naver.com/catalog/21496805761?query=%20i9-10920X&NaPm=ct%3Dkhyuj140%7Cci%3Ddfc386bc09a734c8adff2ceb31840baa549055ee%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3D5d01ae5683b023d9007ad4f1b3fffb942316dc41','����');
Insert into SCOTT.CPU (NAME,PRICE,LINK,COMPANY) values ('i9-9920x',837400,'https://search.shopping.naver.com/catalog/18078561587?query=%20%20i9-9920X&NaPm=ct%3Dkhyuk608%7Cci%3Dff9018063654f35f843ed439ca34cd38a93cdae4%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3D589cdc3a17975907a992a8a9dc3f05355c5a6b34','����');
Insert into SCOTT.CPU (NAME,PRICE,LINK,COMPANY) values ('i9-10900xf',596280,'https://search.shopping.naver.com/catalog/24041421523?query=i9-10900KF&NaPm=ct%3Dkhyumjnk%7Cci%3D16cd19fa9c8a5023c20b199250b397600a15e617%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3D724654e123511c59f6719cfaedb592fb780caa6c','����');
Insert into SCOTT.CPU (NAME,PRICE,LINK,COMPANY) values ('i9-10850k',537550,'https://search.shopping.naver.com/catalog/24197023523?query=i9-10850K&NaPm=ct%3Dkhyunw9k%7Cci%3Dc93ef19ffce109bca590be3cce6a12378c148724%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3D5fabd311dacaa2c7d06d7b2d5f64b175f67df7c3','����');
Insert into SCOTT.CPU (NAME,PRICE,LINK,COMPANY) values ('i9-10900x',708750,'https://search.shopping.naver.com/catalog/21496805443?query=%20i9-10900X&NaPm=ct%3Dkhyup15s%7Cci%3D17bfc806e1789f2866f5830e91c3f4ae2331c087%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3D3a73cec2410545ebdf2e92c875dd22aae8f7ce9e','����');
Insert into SCOTT.CPU (NAME,PRICE,LINK,COMPANY) values ('i9-9900x',724500,'https://search.shopping.naver.com/catalog/19276677403?query=%20i9-9900X&NaPm=ct%3Dkhyutbhc%7Cci%3D01647f290fb46dab1b9fda4186cd35519157a701%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3D4401e2c649dae60641522827a4284e588bb17915','����');
Insert into SCOTT.CPU (NAME,PRICE,LINK,COMPANY) values ('i9-10900 ',513200,'https://search.shopping.naver.com/catalog/24041270528?query=%20i9-10900%20&NaPm=ct%3Dkhyuyfw8%7Cci%3Df8ebae529bba086d3b1588c5ec7d5388d1cc150f%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3D741388bd651ed8d26683a7c158d60aaa2b21c2f6','����');
Insert into SCOTT.CPU (NAME,PRICE,LINK,COMPANY) values ('i9-10900f',501390,'https://search.shopping.naver.com/search/all?query=i9-10900F&frm=NVSHATC&prevQuery=%20i9-10900','����');
Insert into SCOTT.CPU (NAME,PRICE,LINK,COMPANY) values ('r7-4750g',372630,'https://search.shopping.naver.com/catalog/24279697524?query=Ryzen%207%20PRO%204750G&NaPm=ct%3Dkhyv0l20%7Cci%3D382897ffe84765148dbcc2722f61e621d3714ed6%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3D418d176118ee2b719dc04939d1647abda152f20e','AMD');
Insert into SCOTT.CPU (NAME,PRICE,LINK,COMPANY) values ('i7-10700k',428000,'https://search.shopping.naver.com/catalog/24041060530?query=i7-10700K&NaPm=ct%3Dkhyv3ewo%7Cci%3Dcb19d55870c31855b0b4aa25c4c70679b54dcc6f%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3D32bfc0e5586705ddfef2be7596522a679104a3d4','����');
Insert into SCOTT.CPU (NAME,PRICE,LINK,COMPANY) values ('i7-10700kf',411600,'https://search.shopping.naver.com/catalog/24041720525?query=%20i7-10700KF&NaPm=ct%3Dkhyv4m48%7Cci%3Dc5077527d08d505cb57c3ef058d27806dab99897%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3Dae500208cd6ea3eb6d18e6b3dc3e8840a4cd8731','����');
Insert into SCOTT.CPU (NAME,PRICE,LINK,COMPANY) values ('i9-9900ks',1564000,'https://search.shopping.naver.com/catalog/21389064256?query=%20i9-9900KS&NaPm=ct%3Dkhyv55eo%7Cci%3D7f1c97bb97daa3d9e142362ef89de5cd58e98abd%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3D9713c7a5ae6d163562f3f71e2032f8406bcf25e5','����');
Insert into SCOTT.CPU (NAME,PRICE,LINK,COMPANY) values ('r5-3600x',263170,'https://search.shopping.naver.com/catalog/20071591866?query=Ryzen%205%203600X&NaPm=ct%3Dkhyv7yhk%7Cci%3Dd8bc3bd6abc60e17d5b190781d9a0ea0b0ce12c6%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3D1820f545634a5e3c36ae6f5608467b2cd8effe4b','AMD');
Insert into SCOTT.CPU (NAME,PRICE,LINK,COMPANY) values ('i5-4430',69900,'https://search.shopping.naver.com/search/all?query=intel%20i5%204460&frm=NVSHATC&prevQuery=i5%204460','����');
Insert into SCOTT.CPU (NAME,PRICE,LINK,COMPANY) values ('r5-3500',146960,'https://search.shopping.naver.com/search/all?frm=NVSHATC&origQuery=%EB%9D%BC%EC%9D%B4%EC%A0%A0%20r5%203500&pagingIndex=1&pagingSize=40&productSet=total&query=%EB%9D%BC%EC%9D%B4%EC%A0%A0%20r5%203500&sort=rel&timestamp=&viewType=list','������');
Insert into SCOTT.CPU (NAME,PRICE,LINK,COMPANY) values ('i5-9400f',150000,'https://search.shopping.naver.com/catalog/17184851513?query=%EC%9D%B8%ED%85%949%EC%84%B8%EB%8C%80%20%EC%BB%A4%ED%94%BCR%20i5%209400F%202.90GHz%20%5B6%EC%BD%94%EC%96%B46%EC%93%B0%EB%A0%88%EB%93%9C%5D%20%ED%84%B0%EB%B3%B4%204.10GHz&NaPm=ct%3Dkhu906lc%7Cci%3De26a2b79710f55e4125755ab2d0265642580e99d%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3D66fd7351ea74241863df225c9635e82abafede3d','����');
Insert into SCOTT.CPU (NAME,PRICE,LINK,COMPANY) values ('i5-9500f',157000,'https://search.shopping.naver.com/catalog/19837558612?query=%EC%9D%B8%ED%85%949%EC%84%B8%EB%8C%80%20%EC%BB%A4%ED%94%BCR%20i5%209500F%203.00GHz%20%5B6%EC%BD%94%EC%96%B46%EC%93%B0%EB%A0%88%EB%93%9C%5D%20%ED%84%B0%EB%B3%B4%204.40GHz&NaPm=ct%3Dkhu97980%7Cci%3D2f7047d1ced3c552d57380293312ab402ee896fe%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3Dde45a43b12e9dd9fd92ec815ddbe596b70ace060','����');
Insert into SCOTT.CPU (NAME,PRICE,LINK,COMPANY) values ('i5-10400f',173000,'https://search.shopping.naver.com/catalog/24041521529?query=%EC%9D%B8%ED%85%9410%EC%84%B8%EB%8C%80%20%EC%BD%94%EB%A9%A7%20i5%2010400F%202.9GHz%20%5B6%EC%BD%94%EC%96%B412%EC%93%B0%EB%A0%88%EB%93%9C%5D%20%ED%84%B0%EB%B3%B44.3GHz&NaPm=ct%3Dkhu9hfqg%7Cci%3Df0fa3f4dfe1b8362c1cf8417306d64ffdd4b7c28%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3Df6935e44ab7c3c082995f5b0b920c4ce8a073b17','����');
Insert into SCOTT.CPU (NAME,PRICE,LINK,COMPANY) values ('i7-9700',270000,'https://search.shopping.naver.com/catalog/21032211461?query=%EC%9D%B8%ED%85%949%EC%84%B8%EB%8C%80%20%EC%BB%A4%ED%94%BCR%20i7%209700%203.0GHz%20%5B8%EC%BD%94%EC%96%B4%2F8%EC%93%B0%EB%A0%88%EB%93%9C%5D%20%ED%84%B0%EB%B3%B4%204.7GHz&NaPm=ct%3Dkhu9m034%7Cci%3D3b83271a5a1c4490aef6992add6a513243a95d0a%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3Dd8a57694b108575c60dee1964a36d9f152fc84a1','����');
Insert into SCOTT.CPU (NAME,PRICE,LINK,COMPANY) values ('i5-10400',190000,'https://search.shopping.naver.com/catalog/24042015523?query=i5-10400&NaPm=ct%3Dkhvnaxbk%7Cci%3D2386acc9d69b13a014ccf851a6c3d62f0c5b49fb%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3D911d9296d521073936af2c60a39a2d285bcd5ca2','����');
Insert into SCOTT.CPU (NAME,PRICE,LINK,COMPANY) values ('r5-3500x',159000,'https://search.shopping.naver.com/search/all?query=r5-3500x&frm=NVSHATC&prevQuery=i5-10400','������');
Insert into SCOTT.CPU (NAME,PRICE,LINK,COMPANY) values ('r7-3700x',741000,'https://search.shopping.naver.com/search/all?query=r7-3700x&frm=NVSHATC&prevQuery=r5-3500x','������');
Insert into SCOTT.CPU (NAME,PRICE,LINK,COMPANY) values ('i7-10700f',343000,'https://search.shopping.naver.com/catalog/24041845528?query=i7-10700f&NaPm=ct%3Dkhvngua8%7Cci%3De1bd85a1174c8431aecb934935cfd942c71ada8b%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3Dab32ea15b4bb4bf57806322996b83b1c06981301','����');
Insert into SCOTT.CPU (NAME,PRICE,LINK,COMPANY) values ('i7-10700',356000,'https://search.shopping.naver.com/catalog/24041845530?query=i7-10700&NaPm=ct%3Dkhvnhhfk%7Cci%3Da8920073b0dadd3b99e757466997e00a1be8036b%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3D01579860bc9f8e050d1dbbfa86f7f0da176b4f82','����');
Insert into SCOTT.CPU (NAME,PRICE,LINK,COMPANY) values ('r5-5600x',391000,'https://search.shopping.naver.com/search/all?query=AMD%20%EB%9D%BC%EC%9D%B4%EC%A0%A0%20%EC%A0%95%ED%92%88%EB%B0%95%EC%8A%A4%20R5%205600X%20CPU%20(%EB%B2%84%EB%AF%B8%EC%96%B4%2FAM4%2F%EC%BF%A8%EB%9F%AC%ED%8F%AC%ED%95%A8)&frm=NVSHATC&prevQuery=r5-5600x','������');
Insert into SCOTT.CPU (NAME,PRICE,LINK,COMPANY) values ('r7-5800x',750000,'https://search.shopping.naver.com/search/all?query=%EC%83%88%EB%A1%9C%EC%9A%B4%20AMD%20Ryzen%207%205800X%20R7%205800X%20&frm=NVSHATC&prevQuery=%EC%83%88%EB%A1%9C%EC%9A%B4%20AMD%20Ryzen%207%205800X%20R7%205800X%203.8%20GHz%208%20%EC%BD%94%EC%96%B4%2016%20%EC%8A%A4%EB%A0%88%EB%93%9C%20105W%20CPU%20%ED%94%84%EB%A1%9C%EC%84%B8%EC%84%9C%20L3%20%3D%2032M%20100-000000063%20%EC%86%8C%EC%BC%93%20AM4%20%ED%8C%AC%20%EC%97%86%EC%9D%8C','������');
Insert into SCOTT.CPU (NAME,PRICE,LINK,COMPANY) values ('Ŀ�Ƿ���ũ-g5420',66000,'https://search.shopping.naver.com/catalog/20397275327?query=%EC%BB%A4%ED%94%BC%EB%A0%88%EC%9D%B4%ED%81%AC-G5420&NaPm=ct%3Dkhvnqpzs%7Cci%3Dce95e4d50639ed99d8efa536e918f658a172340b%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3D17b26326f9bbd39d8b33ecc0725aef005b2ed1c7','����');
Insert into SCOTT.CPU (NAME,PRICE,LINK,COMPANY) values ('i3-10100f',94000,'https://search.shopping.naver.com/search/all?query=%EC%9D%B8%ED%85%94%20%EC%BD%94%EC%96%B4i3-10%EC%84%B8%EB%8C%80%2010100F&frm=NVSHATC&prevQuery=i3-10100f','����');
Insert into SCOTT.CPU (NAME,PRICE,LINK,COMPANY) values ('�ڸ�-g6400',84000,'https://search.shopping.naver.com/search/all?query=%EC%BD%94%EB%A9%A7-G6400&frm=NVSHATC&prevQuery=%EC%9D%B8%ED%85%94%20%EC%BD%94%EC%96%B4i3-10%EC%84%B8%EB%8C%80%2010100F','����');
Insert into SCOTT.CPU (NAME,PRICE,LINK,COMPANY) values ('r3-3100',121000,'https://search.shopping.naver.com/catalog/22847245426?query=AMD%20%EB%9D%BC%EC%9D%B4%EC%A0%A0%20R3%203100%20%EB%A7%88%ED%8B%B0%EC%8A%A4&NaPm=ct%3Dkhvnux88%7Cci%3D6c55c322514a1bb3a88fa0231c0197772829e3de%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3Dff28a62d97e869f1563a2a457502fe15c63bd773','������');
Insert into SCOTT.CPU (NAME,PRICE,LINK,COMPANY) values ('r5-3600',224000,'https://search.shopping.naver.com/search/all?query=r5-3600&frm=NVSHATC&prevQuery=i3-10100f','������');
Insert into SCOTT.CPU (NAME,PRICE,LINK,COMPANY) values ('i5-10700f',576020,'http://www.tmon.co.kr/deal/4791701346?NaPm=ct%3Dki1qivns%7Cci%3D6ff05146f849ec1cce47950063deed4e0fb20a14%7Ctr%3Dslsl%7Csn%3D221844%7Chk%3D7545bf0be77d106620a367e221ae8020bc37dbc8&coupon_srl=2658070&utm_source=naver&utm_medium=affiliate&utm_term=72093_1008&utm_content=&utm_campaign=META_%EB%84%A4%EC%9D%B4%EB%B2%84%EC%A7%80%EC%8B%9D%EC%87%BC%ED%95%91','����');
Insert into SCOTT.CPU (NAME,PRICE,LINK,COMPANY) values ('i5-10600kf',207980,'https://search.shopping.naver.com/catalog/24041845527?query=i5-10600kf&NaPm=ct%3Dki1qjl4g%7Cci%3D06c603c9cb5821b1e330dd5046d9508b66c248cb%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3Df706857ea703ddc033484c1b776ee70e753ec639','����');
Insert into SCOTT.CPU (NAME,PRICE,LINK,COMPANY) values ('r7-3800xt',380600,'https://usr.icoda.co.kr/item/view/1075144','������');
Insert into SCOTT.CPU (NAME,PRICE,LINK,COMPANY) values ('g6400',69840,'https://search.shopping.naver.com/catalog/24041521531?query=g6400&NaPm=ct%3Dki1qss54%7Cci%3D099498477cdc283d241c6bd0c2ee6a7470511b45%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3D63709d3d9552cbed18ee85c1f9732548ac2ce1c6','����');
Insert into SCOTT.CPU (NAME,PRICE,LINK,COMPANY) values ('g4930',37710,'https://search.shopping.naver.com/catalog/20968502643?query=g4930&NaPm=ct%3Dki1qt7ko%7Cci%3Db1dd274ef9c42f2d270ac37c37bf41c0eea8db5f%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3D639d129900fee2aaff82a7698e09ea423ecb1b19','����');
Insert into SCOTT.CPU (NAME,PRICE,LINK,COMPANY) values ('g5905',41300,'https://search.shopping.naver.com/catalog/24041333522?query=g5905&NaPm=ct%3Dki1qtn08%7Cci%3Dc7eaf22427e3ffdb0dab89884cdc10a7a92de0b2%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3D6426b1e3773f84d24e91f9b429f9cad94e61387d','����');
Insert into SCOTT.CPU (NAME,PRICE,LINK,COMPANY) values ('i9-10900kf',591100,'https://search.shopping.naver.com/catalog/24041421523?query=i9-10900kf&NaPm=ct%3Dki1qu37k%7Cci%3De2fe64141eaea59a362b098b84838ce3418991ff%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3D03b25e761fde97a617d91a9404bece26c9530451','����');
Insert into SCOTT.CPU (NAME,PRICE,LINK,COMPANY) values ('g5420',66000,'https://search.shopping.naver.com/catalog/20397275327?query=%EC%BB%A4%ED%94%BC%EB%A0%88%EC%9D%B4%ED%81%AC-G5420&NaPm=ct%3Dkhvnqpzs%7Cci%3Dce95e4d50639ed99d8efa536e918f658a172340b%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3D17b26326f9bbd39d8b33ecc0725aef005b2ed1c7','����');
Insert into SCOTT.CPU (NAME,PRICE,LINK,COMPANY) values ('h410h6-m7',73350,'https://search.shopping.naver.com/search/all?query=H410H6-M7&frm=NVSHATC','����');
Insert into SCOTT.CPU (NAME,PRICE,LINK,COMPANY) values ('i5-10500',205920,'https://search.shopping.naver.com/catalog/24040965531?query=i5-10500&NaPm=ct%3Dkhzzdlp4%7Cci%3D8db03a64f8fac1f77545f9a19e73d025d4f8f1a6%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3D202b03425515c29f3497b25398f8aa48501fc1fd','����');
Insert into SCOTT.CPU (NAME,PRICE,LINK,COMPANY) values ('i9-10850ka',973100,'https://search.shopping.naver.com/search/all?query=i9-10850ka&frm=NVSHATC&prevQuery=i5-10500','����');
Insert into SCOTT.CPU (NAME,PRICE,LINK,COMPANY) values ('r9-3900x',774600,'https://search.shopping.naver.com/search/all?query=r9-3900x&frm=NVSHATC&prevQuery=r7-3800xt','amd');
--------------------------------------------------------
--  DDL for Index SYS_C0011951
--------------------------------------------------------

  CREATE UNIQUE INDEX "SCOTT"."SYS_C0011951" ON "SCOTT"."CPU" ("NAME") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  Constraints for Table CPU
--------------------------------------------------------

  ALTER TABLE "SCOTT"."CPU" MODIFY ("NAME" NOT NULL ENABLE);
 
  ALTER TABLE "SCOTT"."CPU" MODIFY ("PRICE" NOT NULL ENABLE);
 
  ALTER TABLE "SCOTT"."CPU" ADD PRIMARY KEY ("NAME")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS"  ENABLE;
