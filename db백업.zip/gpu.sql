--------------------------------------------------------
--  ������ ������ - ������-11��-30-2020   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Table GPU
--------------------------------------------------------

  CREATE TABLE "SCOTT"."GPU" 
   (	"NAME" VARCHAR2(50 BYTE), 
	"PRICE" NUMBER, 
	"LINK" VARCHAR2(1000 BYTE), 
	"COMPANY" VARCHAR2(50 BYTE)
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
REM INSERTING into SCOTT.GPU
SET DEFINE OFF;
Insert into SCOTT.GPU (NAME,PRICE,LINK,COMPANY) values ('rtx2080',1137000,'https://search.shopping.naver.com/catalog/20952208261?query=RTX%202080&NaPm=ct%3Dkhyribj4%7Cci%3D22bace2693023c27b3426749692f2779258f6df5%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3D5894aef33e9ea58e31b094d114c99131b8625507','����');
Insert into SCOTT.GPU (NAME,PRICE,LINK,COMPANY) values ('rtx8000',7597550,'https://search.shopping.naver.com/catalog/18842321596?query=RTX%208000&NaPm=ct%3Dkhyrjyy0%7Cci%3D760430c06f439d09c996aaa365ae90ecc55c6927%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3Df9cc34a30752da553a093ee2238481d876b833c4','������');
Insert into SCOTT.GPU (NAME,PRICE,LINK,COMPANY) values ('rtx2070',596000,'https://search.shopping.naver.com/catalog/20052562449?query=RTX%202070&NaPm=ct%3Dkhyrl3u8%7Cci%3D4864482c8b7224ca6cb851755cbcb4c5e89184c7%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3D8922c5493349a4599127d6292c0734025f0319ae','������');
Insert into SCOTT.GPU (NAME,PRICE,LINK,COMPANY) values ('gtx1080',1190000,'https://search.shopping.naver.com/catalog/11414334335?query=GTX%201080&NaPm=ct%3Dkhyrmjjc%7Cci%3D5bae4f7230f9029cedc2c31de98477db989a9245%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3Df12ad5b53281e248952c946ebea257aee335594e','�÷�Ǯ');
Insert into SCOTT.GPU (NAME,PRICE,LINK,COMPANY) values ('rtx4000',1264570,'https://search.shopping.naver.com/catalog/21157557661?query=RTX%204000&NaPm=ct%3Dkhyrnwx4%7Cci%3Daa34e22d31e03dccb069a39c07522c67e781b23d%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3D0c129247ff443319a990fb89d78c42997e5fa1c3','������');
Insert into SCOTT.GPU (NAME,PRICE,LINK,COMPANY) values ('rx5700',546000,'https://search.shopping.naver.com/catalog/22357897125?query=RX%205700&NaPm=ct%3Dkhyrou3k%7Cci%3D3390dbc02bbd3ed9ad5ba40aad51bca2314ad05b%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3Dd008c9b22200931c25ce68dc22c57fcdac98fcfb','SAPPHIRE');
Insert into SCOTT.GPU (NAME,PRICE,LINK,COMPANY) values ('rtx5000',2752430,'https://search.shopping.naver.com/catalog/18842548245?query=RTX%205000&NaPm=ct%3Dkhyrq6pk%7Cci%3D15882f89dfaefd27bd8008204ebd6b1119e87f7c%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3D0329dac842dfa9cfb0d17cbcff118384bab98a64','������');
Insert into SCOTT.GPU (NAME,PRICE,LINK,COMPANY) values ('rtx6000',5989000,'https://search.shopping.naver.com/search/all?query=RTX%206000&frm=NVSHATC&prevQuery=%20RTX%202060','NVDIA');
Insert into SCOTT.GPU (NAME,PRICE,LINK,COMPANY) values ('w5700',154000,'https://search.shopping.naver.com/search/all?query=W5700&frm=NVSHATC&prevQuery=P6000','AMD');
Insert into SCOTT.GPU (NAME,PRICE,LINK,COMPANY) values ('gtx1070',620100,'https://search.shopping.naver.com/catalog/9947399137?query=GTX%201070&NaPm=ct%3Dkhyrwq1s%7Cci%3D99b6611e81dc435696725a4259d94ed2faa0ba66%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3D356af630ac10e6d6f2ecebd8be8e824a3e8da097','�Ⱑ����Ʈ');
Insert into SCOTT.GPU (NAME,PRICE,LINK,COMPANY) values ('gtx980',989100,'https://search.shopping.naver.com/catalog/9139401465?query=GTX%20980&NaPm=ct%3Dkhyrxn88%7Cci%3D4a5b4bc4836ca94953f34a97d85f225218d018ab%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3D456d46a841b22365ecfb5f718525b35e6acd400d','�Ⱑ����Ʈ');
Insert into SCOTT.GPU (NAME,PRICE,LINK,COMPANY) values ('wx8200',1775400,'https://search.shopping.naver.com/search/all?query=WX%208200&frm=NVSHATC&prevQuery=GTX%20980','AMD');
Insert into SCOTT.GPU (NAME,PRICE,LINK,COMPANY) values ('rx5600',335000,'https://search.shopping.naver.com/catalog/21839845740?query=RX%205600&NaPm=ct%3Dkhys1kfk%7Cci%3D4ca6ce5147cf225fa6cdbcdb165b899098827b99%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3Dea211b82d16f19a96d444c0e29adfc395b4fd174','MSI');
Insert into SCOTT.GPU (NAME,PRICE,LINK,COMPANY) values ('p4000',1395000,'https://search.shopping.naver.com/catalog/11336096524?query=P4000&NaPm=ct%3Dkhys3u80%7Cci%3Db93cf6213ee02b7369b27583ce3e47cc5bae5cf1%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3D84f086172c0b3c3009d10d0fc0da306a9dbf6f20','������');
Insert into SCOTT.GPU (NAME,PRICE,LINK,COMPANY) values ('vega-56',563400,'https://search.shopping.naver.com/catalog/13075607136?query=Vega%2056&NaPm=ct%3Dkhys4s68%7Cci%3D37f6f95365e4cd8781ac5fa1618e9f07852964fe%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3Dbb4b0277e1810b57630a7b02ed52e5e021596add','�Ⱑ����Ʈ');
Insert into SCOTT.GPU (NAME,PRICE,LINK,COMPANY) values ('rx590',358190,'https://search.shopping.naver.com/catalog/18240226571?query=RX%20590&NaPm=ct%3Dkhysbqy0%7Cci%3Db130ae2ff951ce2a1c03aa0d2d83470ededa7f32%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3D4d3de0980f4b8a956fa4f2b50871c6a277320053','ASUS');
Insert into SCOTT.GPU (NAME,PRICE,LINK,COMPANY) values ('gtx1650',225000,'https://search.shopping.naver.com/catalog/21934315375?query=%5B%EC%A7%80%ED%8F%AC%EC%8A%A4%5D%20GTX1650%20P%204GB%5BASUS%5D=ct%3Dkhu8ny08%7Cci%3Dd06401821515a0ce14e096cfcd259395098077c5%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3D2ab3ccfc1921670c3401db0d6bf640438f81fb03','ASUS');
Insert into SCOTT.GPU (NAME,PRICE,LINK,COMPANY) values ('gtx1660',291000,'https://search.shopping.naver.com/catalog/21329625582?query=%5B%EC%A7%80%ED%8F%AC%EC%8A%A4%5D%20GTX1660%206GB%20%5BASUS%5D=ct%3Dkhu8san4%7Cci%3D8270fdeacdd0e70aaa50637c162aa438701d8a8b%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3Ddfb94791a23149bd903da2785c17a478129afdca','ASUS');
Insert into SCOTT.GPU (NAME,PRICE,LINK,COMPANY) values ('gtx1660s',389000,'https://search.shopping.naver.com/search/all?query=%EC%A7%80%ED%8F%AC%EC%8A%A4gtx1660S&frm=NVSHATC&prevQuery=%EC%A7%80%ED%8F%AC%EC%8A%A4gtx1660super','ASUS');
Insert into SCOTT.GPU (NAME,PRICE,LINK,COMPANY) values ('rtx2060',392000,'https://search.shopping.naver.com/catalog/17068895938?query=rtx2060&NaPm=ct%3Dkhvyq96w%7Cci%3Dce51822562629067b3abcf62c865060ddb05e8b2%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3D947e6a3740541adaaa042509f7187df9b4d025f2','MSI');
Insert into SCOTT.GPU (NAME,PRICE,LINK,COMPANY) values ('rtx2070-super',617000,'https://search.shopping.naver.com/catalog/20052562449?query=rtx2070-super&NaPm=ct%3Dkhvyro48%7Cci%3D651449a02031524050b4b6d289609aaa1c86c47d%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3D60b97458a0e9362d406fa2276e501222feb21e9a','������');
Insert into SCOTT.GPU (NAME,PRICE,LINK,COMPANY) values ('rtx3070',680000,'https://search.shopping.naver.com/catalog/24715289522?adId=nad-a001-02-000000111572337&channel=nshop.npla&query=rtx3070&NaPm=ct%3Dkhvzny5k%7Cci%3D0yS0001n1%5FPtsQd5VeZa%7Ctr%3Dpla%7Chk%3D242e80887f367085fa9756bd075fe892431e5ab4&cid=0yS0001n1_PtsQd5VeZa','����');
Insert into SCOTT.GPU (NAME,PRICE,LINK,COMPANY) values ('gt710',46000,'https://search.shopping.naver.com/catalog/9420189868?query=gt710&NaPm=ct%3Dkhvzp3tk%7Cci%3Dcb3ff6038119aa659be3a5373f0b8cdf845aaeac%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3D87d9c159007aa1d4a23f5b77b6946347df4f9332','������');
Insert into SCOTT.GPU (NAME,PRICE,LINK,COMPANY) values ('gt1030',99000,'https://search.shopping.naver.com/catalog/11596307473?query=gt1030&NaPm=ct%3Dkhvzpx54%7Cci%3D8c6d10a4162c8fc0d9367af3f5e857cfc02f104e%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3D19bca6b83bc86d9074d7f9d65eda1025ed562439','������');
Insert into SCOTT.GPU (NAME,PRICE,LINK,COMPANY) values ('������',0,'https://search.naver.com/search.naver?sm=tab_hty.top&where=nexearch&query=%EB%82%B4%EC%9E%A5%EA%B7%B8%EB%9E%98%ED%94%BD&oquery=%EB%84%A4%EC%9D%B4%EB%B2%84%EC%87%BC%ED%95%91&tqi=U85d5wp0Jy0ss4GQhoosssssslG-401779','-');
Insert into SCOTT.GPU (NAME,PRICE,LINK,COMPANY) values ('rtx-2080',1137000,'https://search.shopping.naver.com/catalog/20952208261?query=RTX%202080&NaPm=ct%3Dkhyribj4%7Cci%3D22bace2693023c27b3426749692f2779258f6df5%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3D5894aef33e9ea58e31b094d114c99131b8625507','����');
Insert into SCOTT.GPU (NAME,PRICE,LINK,COMPANY) values ('rtx-8000',7597550,'https://search.shopping.naver.com/catalog/18842321596?query=RTX%208000&NaPm=ct%3Dkhyrjyy0%7Cci%3D760430c06f439d09c996aaa365ae90ecc55c6927%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3Df9cc34a30752da553a093ee2238481d876b833c4','������');
Insert into SCOTT.GPU (NAME,PRICE,LINK,COMPANY) values ('rtx-2070',596000,'https://search.shopping.naver.com/catalog/20052562449?query=RTX%202070&NaPm=ct%3Dkhyrl3u8%7Cci%3D4864482c8b7224ca6cb851755cbcb4c5e89184c7%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3D8922c5493349a4599127d6292c0734025f0319ae','������');
Insert into SCOTT.GPU (NAME,PRICE,LINK,COMPANY) values ('gtx-1080',1190000,'https://search.shopping.naver.com/catalog/11414334335?query=GTX%201080&NaPm=ct%3Dkhyrmjjc%7Cci%3D5bae4f7230f9029cedc2c31de98477db989a9245%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3Df12ad5b53281e248952c946ebea257aee335594e','�÷�Ǯ');
Insert into SCOTT.GPU (NAME,PRICE,LINK,COMPANY) values ('rtx-4000',1264570,'https://search.shopping.naver.com/catalog/21157557661?query=RTX%204000&NaPm=ct%3Dkhyrnwx4%7Cci%3Daa34e22d31e03dccb069a39c07522c67e781b23d%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3D0c129247ff443319a990fb89d78c42997e5fa1c3','������');
Insert into SCOTT.GPU (NAME,PRICE,LINK,COMPANY) values ('rx-5700',546000,'https://search.shopping.naver.com/catalog/22357897125?query=RX%205700&NaPm=ct%3Dkhyrou3k%7Cci%3D3390dbc02bbd3ed9ad5ba40aad51bca2314ad05b%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3Dd008c9b22200931c25ce68dc22c57fcdac98fcfb','sapphire');
Insert into SCOTT.GPU (NAME,PRICE,LINK,COMPANY) values ('rtx-5000',2752430,'https://search.shopping.naver.com/catalog/18842548245?query=RTX%205000&NaPm=ct%3Dkhyrq6pk%7Cci%3D15882f89dfaefd27bd8008204ebd6b1119e87f7c%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3D0329dac842dfa9cfb0d17cbcff118384bab98a64','������');
Insert into SCOTT.GPU (NAME,PRICE,LINK,COMPANY) values ('rtx-2060',399000,'https://search.shopping.naver.com/catalog/17068895938?query=%20RTX%202060&NaPm=ct%3Dkhyrrrt4%7Cci%3D57e0c5842a3dbcb1d2d5dc5f7b7d11854045b63c%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3Dfabb4e1956547b85bf648285d5c4f9f0982b754f','msi');
Insert into SCOTT.GPU (NAME,PRICE,LINK,COMPANY) values ('rtx-6000',5989000,'https://search.shopping.naver.com/search/all?query=RTX%206000&frm=NVSHATC&prevQuery=%20RTX%202060','nvdia');
Insert into SCOTT.GPU (NAME,PRICE,LINK,COMPANY) values ('gtx-1070',620100,'https://search.shopping.naver.com/catalog/9947399137?query=GTX%201070&NaPm=ct%3Dkhyrwq1s%7Cci%3D99b6611e81dc435696725a4259d94ed2faa0ba66%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3D356af630ac10e6d6f2ecebd8be8e824a3e8da097','�Ⱑ����Ʈ');
Insert into SCOTT.GPU (NAME,PRICE,LINK,COMPANY) values ('gtx-980',989100,'https://search.shopping.naver.com/catalog/9139401465?query=GTX%20980&NaPm=ct%3Dkhyrxn88%7Cci%3D4a5b4bc4836ca94953f34a97d85f225218d018ab%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3D456d46a841b22365ecfb5f718525b35e6acd400d','�Ⱑ����Ʈ');
Insert into SCOTT.GPU (NAME,PRICE,LINK,COMPANY) values ('wx-8200',1775400,'https://search.shopping.naver.com/search/all?query=WX%208200&frm=NVSHATC&prevQuery=GTX%20980','amd');
Insert into SCOTT.GPU (NAME,PRICE,LINK,COMPANY) values ('rx-5600',335000,'https://search.shopping.naver.com/catalog/21839845740?query=RX%205600&NaPm=ct%3Dkhys1kfk%7Cci%3D4ca6ce5147cf225fa6cdbcdb165b899098827b99%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3Dea211b82d16f19a96d444c0e29adfc395b4fd174','msi');
Insert into SCOTT.GPU (NAME,PRICE,LINK,COMPANY) values ('rx-590',358190,'https://search.shopping.naver.com/catalog/18240226571?query=RX%20590&NaPm=ct%3Dkhysbqy0%7Cci%3Db130ae2ff951ce2a1c03aa0d2d83470ededa7f32%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3D4d3de0980f4b8a956fa4f2b50871c6a277320053','asus');
--------------------------------------------------------
--  DDL for Index SYS_C0011960
--------------------------------------------------------

  CREATE UNIQUE INDEX "SCOTT"."SYS_C0011960" ON "SCOTT"."GPU" ("NAME") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  Constraints for Table GPU
--------------------------------------------------------

  ALTER TABLE "SCOTT"."GPU" MODIFY ("NAME" NOT NULL ENABLE);
 
  ALTER TABLE "SCOTT"."GPU" MODIFY ("PRICE" NOT NULL ENABLE);
 
  ALTER TABLE "SCOTT"."GPU" ADD PRIMARY KEY ("NAME")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS"  ENABLE;
