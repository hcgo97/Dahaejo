--------------------------------------------------------
--  ������ ������ - ������-11��-30-2020   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Table POWER
--------------------------------------------------------

  CREATE TABLE "SCOTT"."POWER" 
   (	"NAME" VARCHAR2(50 BYTE), 
	"PRICE" NUMBER, 
	"LINK" VARCHAR2(1000 BYTE), 
	"COMPANY" VARCHAR2(50 BYTE)
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
REM INSERTING into SCOTT.POWER
SET DEFINE OFF;
Insert into SCOTT.POWER (NAME,PRICE,LINK,COMPANY) values ('230w',19000,'https://search.shopping.naver.com/search/all?query=%5B%ED%8C%8C%EC%9B%8C%EC%84%9C%ED%94%8C%EB%9D%BC%EC%9D%B4%5D%20ON%20POWER%20500VE&frm=NVSHATC&prevQuery=%20%5B%EB%82%B4%EC%9E%A5%ED%98%95%5D%20AMD%20%EB%9D%BC%EB%8D%B0%EC%98%A8%20%EB%B2%A0%EA%B0%80%208','PNC');
Insert into SCOTT.POWER (NAME,PRICE,LINK,COMPANY) values ('750w',109000,'https://search.shopping.naver.com/catalog/14184332890?query=POWER&NaPm=ct%3Dkhyvkr4w%7Cci%3D01aed152aa692a6febb74cdac424957d15e57ac3%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3D97b99002e7abc04f49ed39f30b6f5a0a962ec5b5','����');
Insert into SCOTT.POWER (NAME,PRICE,LINK,COMPANY) values ('800w',84500,'https://search.shopping.naver.com/catalog/20020967149?query=POWER&NaPm=ct%3Dkhyvlz48%7Cci%3Dc855f14946f9a45f4e7d0df65f92dd8c8a95b4c0%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3D39040d265764677bdf7391fe371a8369d33a4602','����ũ�δн�');
Insert into SCOTT.POWER (NAME,PRICE,LINK,COMPANY) values ('850w',140500,'https://search.shopping.naver.com/catalog/21918488651?query=POWER&NaPm=ct%3Dkhyvmzds%7Cci%3D2a0da7e320fac8c0cfdf826e9722ae9acb36582d%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3Dc9a0f9e30e5cfca1676d3f9d2d5cfb54161f8237','�üҴ�');
Insert into SCOTT.POWER (NAME,PRICE,LINK,COMPANY) values ('650w',75330,'https://search.shopping.naver.com/catalog/18987622534?query=POWER&NaPm=ct%3Dkhyvnxc0%7Cci%3D35d7f6285014b884c0e804ed29d4d7805c6114e2%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3Db102f05d76052de57a595b20db3ab5f32eead414','����');
Insert into SCOTT.POWER (NAME,PRICE,LINK,COMPANY) values ('550w',59500,'https://search.shopping.naver.com/catalog/11525475569?query=POWER&NaPm=ct%3Dkhyvoqnk%7Cci%3Dada550143fbc5c6a942bc99653014eb12dd2aabf%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3Dc52f7f7aede589a936fc52c8ea6e78572dd9e6e4','����');
Insert into SCOTT.POWER (NAME,PRICE,LINK,COMPANY) values ('1000w',103990,'https://search.shopping.naver.com/catalog/7920777903?query=POWER&NaPm=ct%3Dkhyvr3j4%7Cci%3D8525af8966043444a080465dacc35c815729feef%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3D154339bc0dd4acfd2b5a3bfa0f95b4e70d0fd35f','�߸���ũ');
Insert into SCOTT.POWER (NAME,PRICE,LINK,COMPANY) values ('1050w',179000,'https://search.shopping.naver.com/catalog/24608230522?query=POWER&NaPm=ct%3Dkhyvta8g%7Cci%3De69e5f481b5d93857c868fa58bad9026583b77d1%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3Df6ebd9143d970139c1a3e8dda49ccdb417f13986','����ũ�δн�');
Insert into SCOTT.POWER (NAME,PRICE,LINK,COMPANY) values ('450w',45000,'https://search.shopping.naver.com/catalog/21489689900?query=POWER450W&NaPm=ct%3Dkhyvv0qg%7Cci%3D171848a0809a8e75abe9a242c62a1c47f820ffd7%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3D4acb8530b9ec42ec929638fa463d674fe20e856d','�׷���Ʈ��');
Insert into SCOTT.POWER (NAME,PRICE,LINK,COMPANY) values ('900w',143000,'https://search.shopping.naver.com/catalog/7295604710?query=POWER900W&NaPm=ct%3Dkhyvw434%7Cci%3Df12f2ca7478b03df4f894b7d8ec7c5d5d607ae79%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3D187e4fd69afdd7558e232f338257cd177f61bec9','�׺�');
Insert into SCOTT.POWER (NAME,PRICE,LINK,COMPANY) values ('1100w',170390,'https://search.shopping.naver.com/catalog/7295603906?query=POWER1100W&NaPm=ct%3Dkhyvydvk%7Cci%3D1994b8d802fb632d2a5f25aa0a3212427c892b3f%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3D4182e14718992f4ee27d1cf949364fd0115c309a','�׺�');
Insert into SCOTT.POWER (NAME,PRICE,LINK,COMPANY) values ('500w',32000,'https://search.shopping.naver.com/catalog/24246379522?adId=nad-a001-02-000000107234875&channel=nshop.npla&query=%ED%8C%8C%EC%9B%8C500w&NaPm=ct%3Dkhofk3ow%7Cci%3D0A00000c2Vnt0i8GiL2w%7Ctr%3Dpla%7Chk%3D65d06716573d3dfc25f778358f22d63ecbe556c9&cid=0A00000c2Vnt0i8GiL2w','��ī�̵���Ż');
Insert into SCOTT.POWER (NAME,PRICE,LINK,COMPANY) values ('400w',52000,'https://search.shopping.naver.com/search/all?query=PNC%20PARTNER%20ON_Power%20600%20PLATINUM&frm=NVSHATC&prevQuery=ON-POWER%20600%20ON-POWER%20600%20PLATINUM','PNC');
Insert into SCOTT.POWER (NAME,PRICE,LINK,COMPANY) values ('600w',38000,'https://search.shopping.naver.com/catalog/21798096869?query=%5B600W%5D%20%EC%97%90%EC%9D%B4%EC%9B%90%20600LF%2083%2B&NaPm=ct%3Dkhsu1h7k%7Cci%3D15ab387b24bd73b256a3945a69ec5b4fc34d6f0a%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3D6f943996fc7d6984f02f6e490fc35efe6f1a4c79','���̿�');
Insert into SCOTT.POWER (NAME,PRICE,LINK,COMPANY) values ('700w',75000,'https://search.shopping.naver.com/catalog/11786888017?query=700W&NaPm=ct%3Dkhw160ww%7Cci%3Db4231eb4c55134b6e7999e27dcd4fd28dd857cd7%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3D9bbdf638f42f3804ea75d08c6a79a6c925eb054f','FSP');
--------------------------------------------------------
--  DDL for Index SYS_C0011963
--------------------------------------------------------

  CREATE UNIQUE INDEX "SCOTT"."SYS_C0011963" ON "SCOTT"."POWER" ("NAME") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  Constraints for Table POWER
--------------------------------------------------------

  ALTER TABLE "SCOTT"."POWER" MODIFY ("NAME" NOT NULL ENABLE);
 
  ALTER TABLE "SCOTT"."POWER" MODIFY ("PRICE" NOT NULL ENABLE);
 
  ALTER TABLE "SCOTT"."POWER" ADD PRIMARY KEY ("NAME")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS"  ENABLE;
