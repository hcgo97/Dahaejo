--------------------------------------------------------
--  ������ ������ - ������-11��-30-2020   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Table MAINBOARD
--------------------------------------------------------

  CREATE TABLE "SCOTT"."MAINBOARD" 
   (	"NAME" VARCHAR2(50 BYTE), 
	"PRICE" NUMBER, 
	"LINK" VARCHAR2(1000 BYTE), 
	"COMPANY" VARCHAR2(50 BYTE)
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
REM INSERTING into SCOTT.MAINBOARD
SET DEFINE OFF;
Insert into SCOTT.MAINBOARD (NAME,PRICE,LINK,COMPANY) values ('b550m',227000,'https://search.shopping.naver.com/search/all?query=%20B550M&frm=NVSHATC&prevQuery=ON-POWER%20600VE','MSI');
Insert into SCOTT.MAINBOARD (NAME,PRICE,LINK,COMPANY) values ('a320mh',45000,'https://search.shopping.naver.com/catalog/14295615165?query=A320MH&NaPm=ct%3Dkhyr26ig%7Cci%3De17a156a5b540a259c680b3fd3f0e27c8c979df2%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3De4226f4d30df7440a9a8175a6d727b54ce7e0644','���̿���Ÿ');
Insert into SCOTT.MAINBOARD (NAME,PRICE,LINK,COMPANY) values ('h410m-c',93890,'https://search.shopping.naver.com/search/all?query=H410M-C&frm=NVSHATC','ASUS');
Insert into SCOTT.MAINBOARD (NAME,PRICE,LINK,COMPANY) values ('z77',66240,'https://search.shopping.naver.com/catalog/6508394015?query=%EC%9D%B8%ED%85%94%20Z77&NaPm=ct%3Dkhyw8mpc%7Cci%3Dcbe2806cd060e84efd3f952c1753ce1a9b07c676%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3Dd0ce384901daa2d67c09296258bdbde7a0283e1f','�����');
Insert into SCOTT.MAINBOARD (NAME,PRICE,LINK,COMPANY) values ('h61',35000,'https://search.shopping.naver.com/search/all?query=%EC%9D%B8%ED%85%94%20H61&frm=NVSHATC&prevQuery=%EC%9D%B8%ED%85%94%20Z77','����');
Insert into SCOTT.MAINBOARD (NAME,PRICE,LINK,COMPANY) values ('b75',39000,'https://search.shopping.naver.com/catalog/6356359840?query=%EC%9D%B8%ED%85%94%20B75&NaPm=ct%3Dkhywagag%7Cci%3D310392349e0f520121b3f43622051c5552f9c235%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3D6847b58028614df01b87fa085a029bb716806f4d','�����');
Insert into SCOTT.MAINBOARD (NAME,PRICE,LINK,COMPANY) values ('h67m-itx',279000,'https://search.shopping.naver.com/catalog/5745865934?query=%EC%9D%B8%ED%85%94%20H67&NaPm=ct%3Dkhywdr48%7Cci%3D1d90f713bd0b9e31c4b9d0a373a2fcf27a90f6cb%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3Dc3bbe62c8d8e9e77000c60792a31510d12a3093f','�����');
Insert into SCOTT.MAINBOARD (NAME,PRICE,LINK,COMPANY) values ('h77',109500,'https://search.shopping.naver.com/catalog/6397502214?query=%EC%9D%B8%ED%85%94%20H77&NaPm=ct%3Dkhywffaw%7Cci%3Dd0c18782f3f85ce9c2cd74c7963020d0a717b7be%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3D5b140a989129cb740630869de9d2367ce89b8550','�����');
Insert into SCOTT.MAINBOARD (NAME,PRICE,LINK,COMPANY) values ('b365m-a',97770,'https://search.shopping.naver.com/catalog/17629870288?adId=nad-a001-02-000000054868942&channel=nshop.npla&query=B365M-A&NaPm=ct%3Dkhywknko%7Cci%3D0z00002BH%5FXtDrOpPfi2%7Ctr%3Dpla%7Chk%3D2d24f683ea421ce7784dfe84ef608c01617adff7&cid=0z00002BH_XtDrOpPfi2','ASUS');
Insert into SCOTT.MAINBOARD (NAME,PRICE,LINK,COMPANY) values ('z390',234000,'https://search.shopping.naver.com/catalog/15691313569?query=Z390-A&NaPm=ct%3Dkhywn52w%7Cci%3D40c4e5df2ebbdf4b04b4aedd7802829c147f38a2%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3D498032da0323d86a369c840eb637f47d620e05d8','�����');
Insert into SCOTT.MAINBOARD (NAME,PRICE,LINK,COMPANY) values ('z390-a',317990,'https://search.shopping.naver.com/catalog/17043323948?query=Z390-A&NaPm=ct%3Dkhywo5cg%7Cci%3D4909da8a967b28ef0247cd2795778db4fce7544f%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3D2c14165619fa6a3e764d6b27c0bcdcbe944b57d5','ASUS');
Insert into SCOTT.MAINBOARD (NAME,PRICE,LINK,COMPANY) values ('h370',164000,'https://search.shopping.naver.com/catalog/14006150176?query=H370%20&NaPm=ct%3Dkhywprzk%7Cci%3Decb527ff61eb41b2260298fdfe5d2e5eb78643f7%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3D96f4f66b03f16746e21c57daae499c5d70ed1eb9','�Ⱑ����Ʈ');
Insert into SCOTT.MAINBOARD (NAME,PRICE,LINK,COMPANY) values ('h370m',124410,'https://search.shopping.naver.com/catalog/14255452316?query=H370%20&NaPm=ct%3Dkhywqm2w%7Cci%3D6209a83affe3d932105272ca17365632e8617ab0%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3D45c187050b283ea8f61ec2d4885c24b9c3fdc620','�����');
Insert into SCOTT.MAINBOARD (NAME,PRICE,LINK,COMPANY) values ('h370-f',220490,'https://search.shopping.naver.com/catalog/14128947736?query=H370%20&NaPm=ct%3Dkhywrbjk%7Cci%3Dd0b9da3cbfd397dabf6e8626e3d9f2a3310af2f2%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3De0f02896f5bcecdc40002290710d03d46a81e02e','ASUS');
Insert into SCOTT.MAINBOARD (NAME,PRICE,LINK,COMPANY) values ('x570-p',222440,'https://search.shopping.naver.com/catalog/20747290468?query=X570-P&NaPm=ct%3Dkhyx0dxk%7Cci%3D5bfe573a1ea056c8b3145cd53a64efe9979e9bf5%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3Debe4c6fff8047d79fe7bbb3543c389df75f26210','ASUS');
Insert into SCOTT.MAINBOARD (NAME,PRICE,LINK,COMPANY) values ('x570',282000,'https://search.shopping.naver.com/catalog/20143230065?query=X570-P&NaPm=ct%3Dkhyx1eyw%7Cci%3Dc4a0694383dc680fcdd0d023d9121442f64a35a4%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3D4bcc7a808196072f4fc74200fbfe4a798c49197d','�Ⱑ����Ʈ');
Insert into SCOTT.MAINBOARD (NAME,PRICE,LINK,COMPANY) values ('x570-a',206460,'https://search.shopping.naver.com/catalog/22358857521?query=X570-A&NaPm=ct%3Dkhyx2qt4%7Cci%3D9cecda7ab5cfb325bec7886a88f67579a74472d9%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3D9ac01d377c63393394da3579e1be8a0801a16a06','MSI');
Insert into SCOTT.MAINBOARD (NAME,PRICE,LINK,COMPANY) values ('a320',63000,'https://search.shopping.naver.com/search/all?query=msi%20a320&frm=NVSHATC&prevQuery=a320','msi');
Insert into SCOTT.MAINBOARD (NAME,PRICE,LINK,COMPANY) values ('h310cm',61000,'https://search.shopping.naver.com/search/all?query=ASRock%20H310CM-DVS&frm=NVSHATC&prevQuery=msi%20a320','�����');
Insert into SCOTT.MAINBOARD (NAME,PRICE,LINK,COMPANY) values ('h310mhp',63000,'https://search.shopping.naver.com/search/all?query=%5B%EC%9D%B4%EC%97%A0%ED%85%8D%5D%20H310MHP%20HDMI%20%5B%EC%BB%A4%ED%94%BC%5D&frm=NVSHATC&prevQuery=ASRock%20H310CM-DVS','BIOSTAR');
Insert into SCOTT.MAINBOARD (NAME,PRICE,LINK,COMPANY) values ('h310m-a',71000,'https://search.shopping.naver.com/search/all?query=%20ASUS%20H310M-C%20HDMI%20%5B%EC%BB%A4%ED%94%BC%5D&frm=NVSHATC&prevQuery=%5B%EC%9D%B4%EC%97%A0%ED%85%8D%5D%20H310MHP%20HDMI%20%5B%EC%BB%A4%ED%94%BC%5D','ASUS');
Insert into SCOTT.MAINBOARD (NAME,PRICE,LINK,COMPANY) values ('ex-a320m',76000,'https://search.shopping.naver.com/search/all?query=%20AMD%20%5BASUS%5D%20EX%20A320M-%EA%B2%8C%EC%9D%B4%EB%B0%8D&frm=NVSHATC&prevQuery=%20ASUS%20H310M-C%20HDMI%20%5B%EC%BB%A4%ED%94%BC%5D','ASUS');
Insert into SCOTT.MAINBOARD (NAME,PRICE,LINK,COMPANY) values ('h410m-k',84000,'https://search.shopping.naver.com/search/all?query=ASUS%20H410M-C%20%EC%BD%94%EB%A9%A7%EB%A0%88%EC%9D%B4%ED%81%ACS&frm=NVSHATC&prevQuery=AMD%20%5BASUS%5D%20EX%20A320M-%EA%B2%8C%EC%9D%B4%EB%B0%8D','ASUS');
Insert into SCOTT.MAINBOARD (NAME,PRICE,LINK,COMPANY) values ('h310m-c',69000,'https://search.shopping.naver.com/search/all?query=ASUS%20H310M-C%20HDMI%20&frm=NVSHATC&prevQuery=ASUS%20H310M-C%20HDMI%20%5B%EC%BB%A4%ED%94%BC%5D','ASUS');
Insert into SCOTT.MAINBOARD (NAME,PRICE,LINK,COMPANY) values ('z490',250000,'https://search.shopping.naver.com/search/all?query=GIGABYTE%20Z490%20UD%20%EB%93%80%EB%9F%AC%EB%B8%94%EC%97%90%EB%94%94%EC%85%98&frm=NVSHATC&prevQuery=ASUS%20H310M-C%20HDMI','�Ⱑ����Ʈ');
Insert into SCOTT.MAINBOARD (NAME,PRICE,LINK,COMPANY) values ('b450m-a',101000,'https://search.shopping.naver.com/catalog/15747397493?query=AMD%20%5BASUS%5D%20B450M-A%20%5B%E5%90%8D%E5%93%81%5D&NaPm=ct%3Dkhvm3prk%7Cci%3D73636a9ea97aa327c2a904075c19a33f09d05fe1%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3D656706c89ec798fbebd89f03d457cc5a0baf8c87','ASUS');
Insert into SCOTT.MAINBOARD (NAME,PRICE,LINK,COMPANY) values ('b550m-a',139000,'https://search.shopping.naver.com/search/all?query=%5BASUS%5D%20PRIME%20B550M-A&frm=NVSHATC&prevQuery=AMD%20%5BASUS%5D%20B450M-A%20%5B%E5%90%8D%E5%93%81%5D','ASUS');
Insert into SCOTT.MAINBOARD (NAME,PRICE,LINK,COMPANY) values ('z490-p',221000,'https://search.shopping.naver.com/search/all?query=ASUS%20PRIME%20Z490-V%20%EC%BD%94%EB%A9%A7%EB%A0%88%EC%9D%B4%ED%81%AC&frm=NVSHATC&prevQuery=%5BASUS%5D%20PRIME%20B550M-A','ASUS');
Insert into SCOTT.MAINBOARD (NAME,PRICE,LINK,COMPANY) values ('z490-a',309000,'https://search.shopping.naver.com/search/all?query=ASUS%20PRIME%20Z490-A%20%EC%BD%94%EB%A9%A7%EB%A0%88%EC%9D%B4%ED%81%AC&frm=NVSHATC&prevQuery=ASUS%20PRIME%20Z490-V%20%EC%BD%94%EB%A9%A7%EB%A0%88%EC%9D%B4%ED%81%AC','ASUS');
Insert into SCOTT.MAINBOARD (NAME,PRICE,LINK,COMPANY) values ('x570ud',201000,'https://search.shopping.naver.com/catalog/20622798956?query=%EA%B8%B0%EA%B0%80%EB%B0%94%EC%9D%B4%ED%8A%B8%20X570%20UD%20%EB%93%80%EB%9F%AC%EB%B8%94%EC%97%90%EB%94%94%EC%85%98&NaPm=ct%3Dkhvm9xj4%7Cci%3D75a7f1781d9ae085982cbee20c9d74b665769ded%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3Db382b556b4a0fc6f83e8d74481f3213da90565c1','�Ⱑ����Ʈ');
Insert into SCOTT.MAINBOARD (NAME,PRICE,LINK,COMPANY) values ('h410',81000,'https://search.shopping.naver.com/catalog/24022450525?query=h410&NaPm=ct%3Dkhvo5954%7Cci%3D671c9a3ee46d08bc52b679bbfc188fd62bed9c1c%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3D46d593e4ffe1f5c92be5986c6b8196f6ff769727','�����');
Insert into SCOTT.MAINBOARD (NAME,PRICE,LINK,COMPANY) values ('h310',63000,'https://search.shopping.naver.com/catalog/20515853668?query=h310&NaPm=ct%3Dkhvo8n20%7Cci%3D23052a1391939353d7430d65efc78d9f4c34de41%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3D09e361f48ec315973df84d71a55d18c43f4614b5','���̿���Ÿ');
Insert into SCOTT.MAINBOARD (NAME,PRICE,LINK,COMPANY) values ('b450',121000,'https://search.shopping.naver.com/catalog/18056494062?query=b450&NaPm=ct%3Dkhvp1ym0%7Cci%3D47ac9cc95dcfbea664db968eaf7e1c6e2a04b80f%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3D016b05c07b441b745aa3980355e1774087a9f98a','�Ⱑ����Ʈ');
Insert into SCOTT.MAINBOARD (NAME,PRICE,LINK,COMPANY) values ('b460',115000,'https://search.shopping.naver.com/search/all?query=b460&frm=NVSHATC&prevQuery=ab460','ASUS');
Insert into SCOTT.MAINBOARD (NAME,PRICE,LINK,COMPANY) values ('a520',145000,'https://search.shopping.naver.com/search/all?query=a520&frm=NVSHATC&prevQuery=h310','�Ⱑ����Ʈ');
Insert into SCOTT.MAINBOARD (NAME,PRICE,LINK,COMPANY) values ('a320m-k',68000,'https://search.shopping.naver.com/catalog/18860841043?query=a320m-k&NaPm=ct%3Dkhvp8bs0%7Cci%3D32202fa9d8db4134d977385b530e5054b264432c%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3De97688d78a55f3a46d17a61489192c14aa983e20','ASUS');
Insert into SCOTT.MAINBOARD (NAME,PRICE,LINK,COMPANY) values ('h310m',69000,'https://search.shopping.naver.com/catalog/16474975367?query=h310m&NaPm=ct%3Dkhvp9i7s%7Cci%3D28d412911c8f8431a9f0ea87d2eb1700a25f4dda%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3De6c0d8b4e6dc07192358e3a2e12d9a36ffcacc05','MSI');
Insert into SCOTT.MAINBOARD (NAME,PRICE,LINK,COMPANY) values ('h410mh6-m7',73000,'https://search.shopping.naver.com/search/all?query=h410-M7&frm=NVSHATC&prevQuery=h410MH6','����');
Insert into SCOTT.MAINBOARD (NAME,PRICE,LINK,COMPANY) values ('h410mh',91000,'https://search.shopping.naver.com/search/all?query=h410mh&frm=NVSHATC&prevQuery=h410-M7','����');
Insert into SCOTT.MAINBOARD (NAME,PRICE,LINK,COMPANY) values ('a320am4-m3d',50800,'https://search.shopping.naver.com/catalog/21386256739?query=a320am4-m3d&NaPm=ct%3Dkhvpigqw%7Cci%3D43c17d9f1c59e63d2971dc38452ff9c6c0883d4e%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3D31fe1d0a851cc3c0d98f19717ac2bdcfce16bab5','ECS');
Insert into SCOTT.MAINBOARD (NAME,PRICE,LINK,COMPANY) values ('a320m',75000,'https://search.shopping.naver.com/catalog/18860840897?query=a320m&NaPm=ct%3Dkhvpks2w%7Cci%3Df300eb999e7f6e580eb163bb2823817f45390303%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3D44b63e5f186c9329d2fd9fa19bba63a175ea54fe','ASUS');
Insert into SCOTT.MAINBOARD (NAME,PRICE,LINK,COMPANY) values ('h320m',58000,'https://search.shopping.naver.com/catalog/17978240853?query=ASROCK%20H320M-DVS%20R4.0&NaPm=ct%3Dkhvppwhs%7Cci%3D536fe7d755073a9c1e232767fa7531a9dc20863f%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3Dfb16dbce412e3fe961c815901eb4415d0ba5bc8b','�����');
Insert into SCOTT.MAINBOARD (NAME,PRICE,LINK,COMPANY) values ('h410m-e',93000,'https://search.shopping.naver.com/search/all?query=PRIME%20H410M-E&frm=NVSHATC&prevQuery=h410m-k','ASUS');
Insert into SCOTT.MAINBOARD (NAME,PRICE,LINK,COMPANY) values ('b365m',99000,'https://search.shopping.naver.com/catalog/19109308960?query=b365M&NaPm=ct%3Dkhvpsu7c%7Cci%3Deabb979c6b20dba4036cc9d3cedf2ce936873be6%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3D0a5de057997c75c3a5eb594e819cb6d8761d9c65','�����');
Insert into SCOTT.MAINBOARD (NAME,PRICE,LINK,COMPANY) values ('b450m',106000,'https://search.shopping.naver.com/catalog/20487807867?query=b450m&NaPm=ct%3Dkhvptugw%7Cci%3Ddf5b9bb9a2e93bacab5ebe6a2cc0be6c495ce9ba%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3D07885c9eece3e77fba9ff4fc8a43ea58c4ce9bee','MSI');
Insert into SCOTT.MAINBOARD (NAME,PRICE,LINK,COMPANY) values ('b450m-hdv',80340,'https://search.shopping.naver.com/catalog/17453267522?query=b450m-hdv&NaPm=ct%3Dki1qbi88%7Cci%3D22edb858eed966d17927297d19ca0fd7d7669b11%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3D33ec5f2e45213d050dca44a3142adafe19e4ce78','�����');
Insert into SCOTT.MAINBOARD (NAME,PRICE,LINK,COMPANY) values ('h410h6-m7',73350,'https://search.shopping.naver.com/search/all?query=h410h6-m7&frm=NVSHATC&prevQuery=b450m-hdv','����');
Insert into SCOTT.MAINBOARD (NAME,PRICE,LINK,COMPANY) values ('z490-v',189000,'https://search.shopping.naver.com/search/all?query=z490-v&frm=NVSHATC&prevQuery=h410h6-m7','����');
Insert into SCOTT.MAINBOARD (NAME,PRICE,LINK,COMPANY) values ('h410m',81090,'https://search.shopping.naver.com/catalog/24022450525?query=h410m&NaPm=ct%3Dki1qem40%7Cci%3Df4d3683076325d92da0ebc3b2e3aa466904224a7%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3D8c15eadbaa742430a57701813807ffa44ea0d487','�����');
Insert into SCOTT.MAINBOARD (NAME,PRICE,LINK,COMPANY) values ('a320am4',50730,'https://search.shopping.naver.com/catalog/21386256739?query=a320am4&NaPm=ct%3Dki1qrhug%7Cci%3D71b72d346eda1113f7736ecc703684f3007739b2%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3Db3d605e782d4328507901be68a9aa32fbcf58ee0','ECS');
Insert into SCOTT.MAINBOARD (NAME,PRICE,LINK,COMPANY) values ('g310m',87350,'https://electron.freeship.co.kr/goods/content.asp?guid=5297130&freeship_ep=naver_ep&NaPm=ct%3Dki1qyqnc%7Cci%3Df71d72c9cc416110e171a93ab6eefab840b80d40%7Ctr%3Dslsl%7Csn%3D405974%7Chk%3D04f1b5c190d46c132507b7287ee50eadac103251','�����');
Insert into SCOTT.MAINBOARD (NAME,PRICE,LINK,COMPANY) values ('a550m',227000,'https://search.shopping.naver.com/search/all?query=%20B550M&frm=NVSHATC&prevQuery=ON-POWER%20600VE','msi');
Insert into SCOTT.MAINBOARD (NAME,PRICE,LINK,COMPANY) values ('h310cm-dvs',61690,'https://search.shopping.naver.com/catalog/16149553719?query=h310cm-dvs&NaPm=ct%3Dki007mps%7Cci%3D6ca0ed8d9b2fd480777878e44981a765aa5703a9%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3D7c8f86e9fa40282dcd4579cd84e8610d9e82fab8','�����');
Insert into SCOTT.MAINBOARD (NAME,PRICE,LINK,COMPANY) values ('b460m',132990,'https://search.shopping.naver.com/catalog/23344556494?query=b460m&NaPm=ct%3Dki00h0og%7Cci%3D774b32f6051fddf9ddad69674d428780ea30f039%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3D234a80a841b97ffd2a106f97b195ab8e10dea191','�����');
Insert into SCOTT.MAINBOARD (NAME,PRICE,LINK,COMPANY) values ('b460m-a',115000,'https://search.shopping.naver.com/search/all?query=b460m-a&frm=NVSHATC','asus');
--------------------------------------------------------
--  DDL for Index SYS_C0011954
--------------------------------------------------------

  CREATE UNIQUE INDEX "SCOTT"."SYS_C0011954" ON "SCOTT"."MAINBOARD" ("NAME") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  Constraints for Table MAINBOARD
--------------------------------------------------------

  ALTER TABLE "SCOTT"."MAINBOARD" MODIFY ("NAME" NOT NULL ENABLE);
 
  ALTER TABLE "SCOTT"."MAINBOARD" MODIFY ("PRICE" NOT NULL ENABLE);
 
  ALTER TABLE "SCOTT"."MAINBOARD" ADD PRIMARY KEY ("NAME")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS"  ENABLE;
