--------------------------------------------------------
--  ������ ������ - ������-11��-30-2020   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Table SSDHDD
--------------------------------------------------------

  CREATE TABLE "SCOTT"."SSDHDD" 
   (	"NAME" VARCHAR2(50 BYTE), 
	"PRICE" NUMBER, 
	"LINK" VARCHAR2(1000 BYTE), 
	"COMPANY" VARCHAR2(50 BYTE)
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
REM INSERTING into SCOTT.SSDHDD
SET DEFINE OFF;
Insert into SCOTT.SSDHDD (NAME,PRICE,LINK,COMPANY) values ('ssd-250g',59500,'https://search.shopping.naver.com/catalog/13392901619?query=%EC%82%BC%EC%84%B1%20ssd%201tb&NaPm=ct%3Dkhyvboqw%7Cci%3D122b9db498d8a74567d0f3d1ea446924fb7aa32d%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3D0560d4aa7847dc83938066719f934ff1434caa49','�Ｚ����');
Insert into SCOTT.SSDHDD (NAME,PRICE,LINK,COMPANY) values ('ssd-1t',189000,'https://search.shopping.naver.com/catalog/13392901619?query=%EC%82%BC%EC%84%B1%20ssd%201tb&NaPm=ct%3Dkhyvboqw%7Cci%3D122b9db498d8a74567d0f3d1ea446924fb7aa32d%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3D0560d4aa7847dc83938066719f934ff1434caa49','�Ｚ����');
Insert into SCOTT.SSDHDD (NAME,PRICE,LINK,COMPANY) values ('ssd-4t',784480,'https://search.shopping.naver.com/catalog/13392901619?query=%EC%82%BC%EC%84%B1%20ssd%201tb&NaPm=ct%3Dkhyvboqw%7Cci%3D122b9db498d8a74567d0f3d1ea446924fb7aa32d%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3D0560d4aa7847dc83938066719f934ff1434caa49','�Ｚ����');
Insert into SCOTT.SSDHDD (NAME,PRICE,LINK,COMPANY) values ('ssd-2t',292050,'https://search.shopping.naver.com/catalog/13593527982?query=ssd%201tb&NaPm=ct%3Dkhyvgqug%7Cci%3D6f7b069cb4048d412e59039e59be02b77d81b6a8%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3Dc27bcab6113af795000b7750c64a5ff6b9163465','WD');
Insert into SCOTT.SSDHDD (NAME,PRICE,LINK,COMPANY) values ('ssd-240g',34000,'https://search.shopping.naver.com/catalog/18463314828?query=ssd-240g&NaPm=ct%3Dkhw06txs%7Cci%3D91d1a82053f3e8170af5e8b54d7f6f161e140ed0%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3D7259efea19a28a6dade98bc2c6aea107df9bf780','WD');
Insert into SCOTT.SSDHDD (NAME,PRICE,LINK,COMPANY) values ('ssd-480g',72000,'https://search.shopping.naver.com/catalog/18463314828?query=ssd-480G&NaPm=ct%3Dkhw086js%7Cci%3Dbf77b3b144644f0f5d73e42fbc13c3b1abf470b8%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3D172f7e94aaab3585622f5ac0f19b9d59b85879eb','WD');
Insert into SCOTT.SSDHDD (NAME,PRICE,LINK,COMPANY) values ('ssd-500g',91000,'https://search.shopping.naver.com/catalog/13392901619?query=ssd-500G&NaPm=ct%3Dkhw08ws8%7Cci%3Df2ad8427fb3fab9c406c39e5174a5f245d894526%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3D7a0d9cc20d12ff90eac8b7c658353f4c065a4c3c','�Ｚ����');
Insert into SCOTT.SSDHDD (NAME,PRICE,LINK,COMPANY) values ('ssd-256g',43000,'https://search.shopping.naver.com/catalog/19970326431?query=ssd-256G&NaPm=ct%3Dkhw0afkg%7Cci%3D3168e1df665cc8797d4556c24a1c624f6c0805e4%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3De370a180dfb0d950f36412488014481a438fd199','�Ｚ����');
Insert into SCOTT.SSDHDD (NAME,PRICE,LINK,COMPANY) values ('ssd-128g',64000,'https://search.shopping.naver.com/catalog/19970326431?query=ssd-128G&NaPm=ct%3Dkhw0bcqw%7Cci%3D6cc6fb8f40ddf3a3aa27adf8cfa5d0d0c82b08e2%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3D730016c9c672162a7d659b2dea1abe0af2a27179','�Ｚ����');
Insert into SCOTT.SSDHDD (NAME,PRICE,LINK,COMPANY) values ('ssd-512g',75000,'https://search.shopping.naver.com/catalog/19970326431?query=ssd-128G&NaPm=ct%3Dkhw0bcqw%7Cci%3D6cc6fb8f40ddf3a3aa27adf8cfa5d0d0c82b08e2%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3D730016c9c672162a7d659b2dea1abe0af2a27179','�Ｚ����');
Insert into SCOTT.SSDHDD (NAME,PRICE,LINK,COMPANY) values ('hdd-320g,16m',69290,'https://search.shopping.naver.com/catalog/5228895962?query=hdd&NaPm=ct%3Dki48rfyo%7Cci%3D87a7a489a9347bfc61be3d1f96024541146feadc%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3D12fa0a7b010ae27882559150680503a642590882','������Ʈ');
Insert into SCOTT.SSDHDD (NAME,PRICE,LINK,COMPANY) values ('hdd-750g,32m',169200,'https://search.shopping.naver.com/catalog/5228895962?query=hdd&NaPm=ct%3Dki48rfyo%7Cci%3D87a7a489a9347bfc61be3d1f96024541146feadc%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3D12fa0a7b010ae27882559150680503a642590882','������Ʈ');
Insert into SCOTT.SSDHDD (NAME,PRICE,LINK,COMPANY) values ('hdd-500g,16m',56000,'https://search.shopping.naver.com/catalog/6237346850?query=hdd&NaPm=ct%3Dki481vfs%7Cci%3D70cea36b80d620c1bbfcc1a985d82177aede1b94%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3Ddac26fcd728455259e4465dfda21e49e1212371d','������Ʈ');
Insert into SCOTT.SSDHDD (NAME,PRICE,LINK,COMPANY) values ('hdd-500g,32m',43800,'https://search.shopping.naver.com/catalog/6237346850?query=hdd&NaPm=ct%3Dki481vfs%7Cci%3D70cea36b80d620c1bbfcc1a985d82177aede1b94%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3Ddac26fcd728455259e4465dfda21e49e1212371d','������Ʈ');
Insert into SCOTT.SSDHDD (NAME,PRICE,LINK,COMPANY) values ('hdd-1t,64m',46490,'https://search.shopping.naver.com/catalog/6237346850?query=hdd&NaPm=ct%3Dki481vfs%7Cci%3D70cea36b80d620c1bbfcc1a985d82177aede1b94%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3Ddac26fcd728455259e4465dfda21e49e1212371d','������Ʈ');
Insert into SCOTT.SSDHDD (NAME,PRICE,LINK,COMPANY) values ('hdd-2t,64m',86100,'https://search.shopping.naver.com/catalog/6237346850?query=hdd&NaPm=ct%3Dki481vfs%7Cci%3D70cea36b80d620c1bbfcc1a985d82177aede1b94%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3Ddac26fcd728455259e4465dfda21e49e1212371d','������Ʈ');
Insert into SCOTT.SSDHDD (NAME,PRICE,LINK,COMPANY) values ('hdd-2t,256m',65000,'https://search.shopping.naver.com/catalog/6237346850?query=hdd&NaPm=ct%3Dki481vfs%7Cci%3D70cea36b80d620c1bbfcc1a985d82177aede1b94%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3Ddac26fcd728455259e4465dfda21e49e1212371d','������Ʈ');
Insert into SCOTT.SSDHDD (NAME,PRICE,LINK,COMPANY) values ('hdd-3t,64m',125550,'https://search.shopping.naver.com/catalog/6237346850?query=hdd&NaPm=ct%3Dki481vfs%7Cci%3D70cea36b80d620c1bbfcc1a985d82177aede1b94%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3Ddac26fcd728455259e4465dfda21e49e1212371d','������Ʈ');
Insert into SCOTT.SSDHDD (NAME,PRICE,LINK,COMPANY) values ('hdd-3t,256m',104000,'https://search.shopping.naver.com/catalog/6237346850?query=hdd&NaPm=ct%3Dki481vfs%7Cci%3D70cea36b80d620c1bbfcc1a985d82177aede1b94%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3Ddac26fcd728455259e4465dfda21e49e1212371d','������Ʈ');
Insert into SCOTT.SSDHDD (NAME,PRICE,LINK,COMPANY) values ('hdd-4t,64m',119000,'https://search.shopping.naver.com/catalog/6237346850?query=hdd&NaPm=ct%3Dki481vfs%7Cci%3D70cea36b80d620c1bbfcc1a985d82177aede1b94%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3Ddac26fcd728455259e4465dfda21e49e1212371d','������Ʈ');
Insert into SCOTT.SSDHDD (NAME,PRICE,LINK,COMPANY) values ('hdd-4t,256m',112500,'https://search.shopping.naver.com/catalog/6237346850?query=hdd&NaPm=ct%3Dki481vfs%7Cci%3D70cea36b80d620c1bbfcc1a985d82177aede1b94%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3Ddac26fcd728455259e4465dfda21e49e1212371d','������Ʈ');
Insert into SCOTT.SSDHDD (NAME,PRICE,LINK,COMPANY) values ('hdd-5t,128m',274500,'https://search.shopping.naver.com/catalog/6237346850?query=hdd&NaPm=ct%3Dki481vfs%7Cci%3D70cea36b80d620c1bbfcc1a985d82177aede1b94%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3Ddac26fcd728455259e4465dfda21e49e1212371d','������Ʈ');
Insert into SCOTT.SSDHDD (NAME,PRICE,LINK,COMPANY) values ('hdd-6t,128m',376200,'https://search.shopping.naver.com/catalog/6237346850?query=hdd&NaPm=ct%3Dki481vfs%7Cci%3D70cea36b80d620c1bbfcc1a985d82177aede1b94%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3Ddac26fcd728455259e4465dfda21e49e1212371d','������Ʈ');
Insert into SCOTT.SSDHDD (NAME,PRICE,LINK,COMPANY) values ('hdd-6t,256m',175000,'https://search.shopping.naver.com/catalog/6237346850?query=hdd&NaPm=ct%3Dki481vfs%7Cci%3D70cea36b80d620c1bbfcc1a985d82177aede1b94%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3Ddac26fcd728455259e4465dfda21e49e1212371d','������Ʈ');
Insert into SCOTT.SSDHDD (NAME,PRICE,LINK,COMPANY) values ('hdd-8t,256m',215000,'https://search.shopping.naver.com/catalog/6237346850?query=hdd&NaPm=ct%3Dki481vfs%7Cci%3D70cea36b80d620c1bbfcc1a985d82177aede1b94%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3Ddac26fcd728455259e4465dfda21e49e1212371d','������Ʈ');
Insert into SCOTT.SSDHDD (NAME,PRICE,LINK,COMPANY) values ('hdd-1t,32m',30000,'https://search.shopping.naver.com/catalog/10651316880?query=hdd&NaPm=ct%3Dki48fw2g%7Cci%3Df4029dd8a338e2abdcd6c706a0ab10a69b44ee66%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3Df464aabffa25b69bd1058cac1af9a4d000380d7d','���ù�');
Insert into SCOTT.SSDHDD (NAME,PRICE,LINK,COMPANY) values ('hdd-2t,32m',85500,'https://search.shopping.naver.com/catalog/10651316880?query=hdd&NaPm=ct%3Dki48fw2g%7Cci%3Df4029dd8a338e2abdcd6c706a0ab10a69b44ee66%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3Df464aabffa25b69bd1058cac1af9a4d000380d7d','���ù�');
Insert into SCOTT.SSDHDD (NAME,PRICE,LINK,COMPANY) values ('hdd-3t,32m',119700,'https://search.shopping.naver.com/catalog/10651316880?query=hdd&NaPm=ct%3Dki48fw2g%7Cci%3Df4029dd8a338e2abdcd6c706a0ab10a69b44ee66%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3Df464aabffa25b69bd1058cac1af9a4d000380d7d','���ù�');
Insert into SCOTT.SSDHDD (NAME,PRICE,LINK,COMPANY) values ('hdd-4t,128m',128860,'https://search.shopping.naver.com/catalog/10651316880?query=hdd&NaPm=ct%3Dki48fw2g%7Cci%3Df4029dd8a338e2abdcd6c706a0ab10a69b44ee66%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3Df464aabffa25b69bd1058cac1af9a4d000380d7d','���ù�');
Insert into SCOTT.SSDHDD (NAME,PRICE,LINK,COMPANY) values ('hdd-2t,128m',169000,'https://search.shopping.naver.com/catalog/18344345128?query=hdd&NaPm=ct%3Dki48n08o%7Cci%3D919fea3154df051deb8ee76cde4951bef20bc4bc%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3Dc4ccd59d2ca3658a2ebe38a7fb3bb8c978ae5dd6','������Ʈ');
Insert into SCOTT.SSDHDD (NAME,PRICE,LINK,COMPANY) values ('hdd-160g,7m',60000,'https://search.shopping.naver.com/catalog/5228895962?query=hdd&NaPm=ct%3Dki48rfyo%7Cci%3D87a7a489a9347bfc61be3d1f96024541146feadc%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3D12fa0a7b010ae27882559150680503a642590882','������Ʈ');
Insert into SCOTT.SSDHDD (NAME,PRICE,LINK,COMPANY) values ('hdd-250g,8m',71010,'https://search.shopping.naver.com/catalog/5228895962?query=hdd&NaPm=ct%3Dki48rfyo%7Cci%3D87a7a489a9347bfc61be3d1f96024541146feadc%7Ctr%3Dslsl%7Csn%3D95694%7Chk%3D12fa0a7b010ae27882559150680503a642590882','������Ʈ');
--------------------------------------------------------
--  DDL for Index SYS_C0011966
--------------------------------------------------------

  CREATE UNIQUE INDEX "SCOTT"."SYS_C0011966" ON "SCOTT"."SSDHDD" ("NAME") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  Constraints for Table SSDHDD
--------------------------------------------------------

  ALTER TABLE "SCOTT"."SSDHDD" MODIFY ("NAME" NOT NULL ENABLE);
 
  ALTER TABLE "SCOTT"."SSDHDD" MODIFY ("PRICE" NOT NULL ENABLE);
 
  ALTER TABLE "SCOTT"."SSDHDD" ADD PRIMARY KEY ("NAME")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS"  ENABLE;
