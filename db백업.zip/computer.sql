--------------------------------------------------------
--  ������ ������ - ������-12��-02-2020   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Table COMPUTER
--------------------------------------------------------

  CREATE TABLE "SCOTT"."COMPUTER" 
   (	"NAME" VARCHAR2(50 BYTE), 
	"CPU" VARCHAR2(50 BYTE), 
	"MAINBOARD" VARCHAR2(50 BYTE), 
	"MEMORY" VARCHAR2(50 BYTE), 
	"GPU" VARCHAR2(50 BYTE), 
	"POWER" VARCHAR2(50 BYTE), 
	"SSDHDD" VARCHAR2(50 BYTE), 
	"OPT" VARCHAR2(20 BYTE)
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
REM INSERTING into SCOTT.COMPUTER
SET DEFINE OFF;
Insert into SCOTT.COMPUTER (NAME,CPU,MAINBOARD,MEMORY,GPU,POWER,SSDHDD,OPT) values ('�繫�� 2��','g4930','h310mhp','4g','������','230w','ssd-256g','�ſ쳷��');
Insert into SCOTT.COMPUTER (NAME,CPU,MAINBOARD,MEMORY,GPU,POWER,SSDHDD,OPT) values ('�繫�� 4��','g6400','h410mh','4g','������','230w','ssd-240g','�ſ쳷��');
Insert into SCOTT.COMPUTER (NAME,CPU,MAINBOARD,MEMORY,GPU,POWER,SSDHDD,OPT) values ('�繫�� 3��','g5905','h410mh','4g','������','600w','ssd-240g','�ſ쳷��');
Insert into SCOTT.COMPUTER (NAME,CPU,MAINBOARD,MEMORY,GPU,POWER,SSDHDD,OPT) values ('�繫�� 6��','g5905','h410mh','4g','������','230w','ssd-512g','����');
Insert into SCOTT.COMPUTER (NAME,CPU,MAINBOARD,MEMORY,GPU,POWER,SSDHDD,OPT) values ('�繫�� 7��','g4930','h310mhp','4g','gt710','230w','ssd-128g','����');
Insert into SCOTT.COMPUTER (NAME,CPU,MAINBOARD,MEMORY,GPU,POWER,SSDHDD,OPT) values ('�繫�� 5��','g6400','h410mh','4g','������','230w','ssd-256g','����');
Insert into SCOTT.COMPUTER (NAME,CPU,MAINBOARD,MEMORY,GPU,POWER,SSDHDD,OPT) values ('�繫�� 9��','g6400','h410mh','4g','������','600w','ssd-256g','����');
Insert into SCOTT.COMPUTER (NAME,CPU,MAINBOARD,MEMORY,GPU,POWER,SSDHDD,OPT) values ('�繫�� 12��','g5905','h410mh','4g','������','600w','ssd-512g','�߰�');
Insert into SCOTT.COMPUTER (NAME,CPU,MAINBOARD,MEMORY,GPU,POWER,SSDHDD,OPT) values ('�繫�� 11��','r3-3200g','a320am4-m3d','4g','������','230w','ssd-128g','�߰�');
Insert into SCOTT.COMPUTER (NAME,CPU,MAINBOARD,MEMORY,GPU,POWER,SSDHDD,OPT) values ('�繫�� 8��','g6400','h410mh','4g','������','600w','ssd-256g','�߰�');
Insert into SCOTT.COMPUTER (NAME,CPU,MAINBOARD,MEMORY,GPU,POWER,SSDHDD,OPT) values ('�繫�� 10��','r3-3200g','a320am4-m3d','4g','������','600w','ssd-256g','�߰�');
Insert into SCOTT.COMPUTER (NAME,CPU,MAINBOARD,MEMORY,GPU,POWER,SSDHDD,OPT) values ('�繫�� 18��','i3-10100f','h410h6-m7','8g','gt710','600w','ssd-256g','����');
Insert into SCOTT.COMPUTER (NAME,CPU,MAINBOARD,MEMORY,GPU,POWER,SSDHDD,OPT) values ('�繫�� 17��','r5-3400g','a320am4-m3d','4g','������','600w','ssd-256g','�߰�');
Insert into SCOTT.COMPUTER (NAME,CPU,MAINBOARD,MEMORY,GPU,POWER,SSDHDD,OPT) values ('�繫�� 15��','r5-3400g','a320am4-m3d','8g','������','230w','ssd-256g','�߰�');
Insert into SCOTT.COMPUTER (NAME,CPU,MAINBOARD,MEMORY,GPU,POWER,SSDHDD,OPT) values ('�繫�� 16��','r5-3400g','a320mh','4g','������','600w','ssd-256g','�߰�');
Insert into SCOTT.COMPUTER (NAME,CPU,MAINBOARD,MEMORY,GPU,POWER,SSDHDD,OPT) values ('�繫�� 14��','r3-3200g','a320am4-m3d','4g','������','600w','ssd-512g','����');
Insert into SCOTT.COMPUTER (NAME,CPU,MAINBOARD,MEMORY,GPU,POWER,SSDHDD,OPT) values ('�繫�� 1��','g4930','h310mhp','4g','������','230w','ssd-256g','�߰�');
Insert into SCOTT.COMPUTER (NAME,CPU,MAINBOARD,MEMORY,GPU,POWER,SSDHDD,OPT) values ('�繫�� 19��','i3-10100','h410h6-m7','8g','������','600w','ssd-512g','�߰�');
Insert into SCOTT.COMPUTER (NAME,CPU,MAINBOARD,MEMORY,GPU,POWER,SSDHDD,OPT) values ('�繫�� 13��','r3-3200g','a320am4','4g','������','600w','ssd-512g','����');
Insert into SCOTT.COMPUTER (NAME,CPU,MAINBOARD,MEMORY,GPU,POWER,SSDHDD,OPT) values ('��ġ�� 1��','i3-10100','h410h6-m7','8g','gt1030','600w','ssd-512g','�Ϲ�');
Insert into SCOTT.COMPUTER (NAME,CPU,MAINBOARD,MEMORY,GPU,POWER,SSDHDD,OPT) values ('��ġ�� 2��','i3-10100f','h410mh','4g','gtx1650','600w','ssd-128g','�Ϲ�');
Insert into SCOTT.COMPUTER (NAME,CPU,MAINBOARD,MEMORY,GPU,POWER,SSDHDD,OPT) values ('��ġ�� 5��','i5-9400f','h310mhp','8g','gtx1650','600w','ssd-128g','�Ϲ�');
Insert into SCOTT.COMPUTER (NAME,CPU,MAINBOARD,MEMORY,GPU,POWER,SSDHDD,OPT) values ('��ġ�� 3��','i3-10100f','h410mh','8g','gtx1650','600w','ssd-128g','�Ϲ�');
Insert into SCOTT.COMPUTER (NAME,CPU,MAINBOARD,MEMORY,GPU,POWER,SSDHDD,OPT) values ('��ġ�� 8��','i5-9400f','h310m-c','8g','gtx1660','600w','ssd-128g','�߿�');
Insert into SCOTT.COMPUTER (NAME,CPU,MAINBOARD,MEMORY,GPU,POWER,SSDHDD,OPT) values ('��ġ�� 4��','i5-9400f','h310m-c','8g','gtx1650','600w','ssd-256g','�߿�');
Insert into SCOTT.COMPUTER (NAME,CPU,MAINBOARD,MEMORY,GPU,POWER,SSDHDD,OPT) values ('��ġ�� 7��','i5-10400f','h410m-c','8g','gtx1650','600w','ssd-240g','�߿�');
Insert into SCOTT.COMPUTER (NAME,CPU,MAINBOARD,MEMORY,GPU,POWER,SSDHDD,OPT) values ('��ġ�� 13��','i5-10600kf','h410m','8g','gtx1660','750w','ssd-256g','�߿�');
Insert into SCOTT.COMPUTER (NAME,CPU,MAINBOARD,MEMORY,GPU,POWER,SSDHDD,OPT) values ('��ġ�� 9��','r5-3500x','b450m-a','8g','gtx1660','600w','ssd-240g','Ǯ��');
Insert into SCOTT.COMPUTER (NAME,CPU,MAINBOARD,MEMORY,GPU,POWER,SSDHDD,OPT) values ('��ġ�� 14��','r7-3800xt','b450m-a','16g','rtx2060','750w','ssd-256g','Ǯ��');
Insert into SCOTT.COMPUTER (NAME,CPU,MAINBOARD,MEMORY,GPU,POWER,SSDHDD,OPT) values ('��ġ�� 15��','i9-10900f','z490-v','16g','gtx1660','600w','ssd-512g','Ǯ��');
Insert into SCOTT.COMPUTER (NAME,CPU,MAINBOARD,MEMORY,GPU,POWER,SSDHDD,OPT) values ('��ġ�� 16��','i9-10900kf','z490-v','32g','rtx2060','700w','ssd-500g','Ǯ��');
Insert into SCOTT.COMPUTER (NAME,CPU,MAINBOARD,MEMORY,GPU,POWER,SSDHDD,OPT) values ('��ġ�� 6��','r5-3500','b450m-a','8g','gtx1650','600w','ssd-256g','���');
Insert into SCOTT.COMPUTER (NAME,CPU,MAINBOARD,MEMORY,GPU,POWER,SSDHDD,OPT) values ('��ġ�� 10��','r5-3500x','a320m','16g','gtx1660','600w','ssd-256g','���');
Insert into SCOTT.COMPUTER (NAME,CPU,MAINBOARD,MEMORY,GPU,POWER,SSDHDD,OPT) values ('��ġ�� 11��','i5-10600kf','h410m-c','8g','gtx1660','600w','ssd-240g','���');
Insert into SCOTT.COMPUTER (NAME,CPU,MAINBOARD,MEMORY,GPU,POWER,SSDHDD,OPT) values ('��ġ�� 12��','r5-3500x','a320m','16g','gtx1660','600w','ssd-512g','���');
Insert into SCOTT.COMPUTER (NAME,CPU,MAINBOARD,MEMORY,GPU,POWER,SSDHDD,OPT) values ('���Ŀ� 1��','g6400','h410h6-m7','4g','gt1030','600w','ssd-128g','����');
Insert into SCOTT.COMPUTER (NAME,CPU,MAINBOARD,MEMORY,GPU,POWER,SSDHDD,OPT) values ('���Ŀ� 8��','r5-3500','a320mh','8g','gtx1650','600w','ssd-512g','����');
Insert into SCOTT.COMPUTER (NAME,CPU,MAINBOARD,MEMORY,GPU,POWER,SSDHDD,OPT) values ('���Ŀ� 3��','r5-3500','a320mh','8g','gtx1650','600w','ssd-256g','����');
Insert into SCOTT.COMPUTER (NAME,CPU,MAINBOARD,MEMORY,GPU,POWER,SSDHDD,OPT) values ('���Ŀ� 2��','i3-10100f','h410m-c','8g','gtx1650','600w','ssd-256g','����');
Insert into SCOTT.COMPUTER (NAME,CPU,MAINBOARD,MEMORY,GPU,POWER,SSDHDD,OPT) values ('���Ŀ� 4��','i3-10100f','h410mh','4g','gtx1650','600w','ssd-512g','�߿�');
Insert into SCOTT.COMPUTER (NAME,CPU,MAINBOARD,MEMORY,GPU,POWER,SSDHDD,OPT) values ('���Ŀ� 6��','i3-10100f','h410mh','8g','gtx1650','600w','ssd-512g','�߿�');
Insert into SCOTT.COMPUTER (NAME,CPU,MAINBOARD,MEMORY,GPU,POWER,SSDHDD,OPT) values ('���Ŀ� 7��','r5-3500','a320m','8g','gtx1650','600w','ssd-256g','�߿�');
Insert into SCOTT.COMPUTER (NAME,CPU,MAINBOARD,MEMORY,GPU,POWER,SSDHDD,OPT) values ('���Ŀ� 5��','i3-10100f','h410mh','8g','gtx1650','600w','ssd-128g','���');
Insert into SCOTT.COMPUTER (NAME,CPU,MAINBOARD,MEMORY,GPU,POWER,SSDHDD,OPT) values ('���Ŀ� 10��','i3-10100f','h410m-c','8g','gtx1660','600w','ssd-256g','���');
Insert into SCOTT.COMPUTER (NAME,CPU,MAINBOARD,MEMORY,GPU,POWER,SSDHDD,OPT) values ('���Ŀ� 9��','i5-9400f','h310m-c','8g','gtx1650','600w','ssd-128g','���');
Insert into SCOTT.COMPUTER (NAME,CPU,MAINBOARD,MEMORY,GPU,POWER,SSDHDD,OPT) values ('���Ŀ� 11��','r5-3600','b450m-hdv','8g','gtx1660','600w','ssd-256g','Ǯ��');
Insert into SCOTT.COMPUTER (NAME,CPU,MAINBOARD,MEMORY,GPU,POWER,SSDHDD,OPT) values ('���Ŀ� 12��','r7-5800x','b550m','8g','gtx1660','600w','ssd-512g','Ǯ��');
Insert into SCOTT.COMPUTER (NAME,CPU,MAINBOARD,MEMORY,GPU,POWER,SSDHDD,OPT) values ('��׿� 3��','i5-10400','h410','16g','gtx1650','500w','ssd-240g','�ſ쳷��');
Insert into SCOTT.COMPUTER (NAME,CPU,MAINBOARD,MEMORY,GPU,POWER,SSDHDD,OPT) values ('��׿� 1��','r5-3500','a320','16g','gtx1650','500w','ssd-240g','�ſ쳷��');
Insert into SCOTT.COMPUTER (NAME,CPU,MAINBOARD,MEMORY,GPU,POWER,SSDHDD,OPT) values ('��׿� 2��','i5-10400f','h410','16g','gtx1650','500w','ssd-240g','�ſ쳷��');
Insert into SCOTT.COMPUTER (NAME,CPU,MAINBOARD,MEMORY,GPU,POWER,SSDHDD,OPT) values ('��׿� 4��','i5-9400f','h310','16g','gtx1660','500w','ssd-240g','�߰�');
Insert into SCOTT.COMPUTER (NAME,CPU,MAINBOARD,MEMORY,GPU,POWER,SSDHDD,OPT) values ('��׿� 5��','i5-10400','h410','16g','gtx1660','600w','ssd-240g','�߰�');
Insert into SCOTT.COMPUTER (NAME,CPU,MAINBOARD,MEMORY,GPU,POWER,SSDHDD,OPT) values ('��׿� 6��','i5-10400f','h410','16g','gtx1660','500w','ssd-480g','�߰�');
Insert into SCOTT.COMPUTER (NAME,CPU,MAINBOARD,MEMORY,GPU,POWER,SSDHDD,OPT) values ('��׿� 9��','i5-10400','h410','16g','gtx1660s','500w','ssd-240g','�߰�');
Insert into SCOTT.COMPUTER (NAME,CPU,MAINBOARD,MEMORY,GPU,POWER,SSDHDD,OPT) values ('��׿� 8��','r5-3500x','a320','16g','rtx2060','600w','ssd-240g','���οɼ�');
Insert into SCOTT.COMPUTER (NAME,CPU,MAINBOARD,MEMORY,GPU,POWER,SSDHDD,OPT) values ('��׿� 7��','i5-9400f','h310','16g','rtx2060','600w','ssd-240g','���οɼ�');
Insert into SCOTT.COMPUTER (NAME,CPU,MAINBOARD,MEMORY,GPU,POWER,SSDHDD,OPT) values ('��׿� 10��','i5-10400','h410','16g','rtx2060','600w','ssd-240g','���οɼ�');
Insert into SCOTT.COMPUTER (NAME,CPU,MAINBOARD,MEMORY,GPU,POWER,SSDHDD,OPT) values ('��׿� 14��','r7-3700x','b450','16g','rtx2070-super','700w','ssd-500g','��Ʈ��');
Insert into SCOTT.COMPUTER (NAME,CPU,MAINBOARD,MEMORY,GPU,POWER,SSDHDD,OPT) values ('��׿� 12��','i7-10700f','b460','16g','rtx3070','700w','ssd-500g','��Ʈ��');
Insert into SCOTT.COMPUTER (NAME,CPU,MAINBOARD,MEMORY,GPU,POWER,SSDHDD,OPT) values ('��׿� 11��','i7-10700','b460','16g','rtx3070','700w','ssd-240g','��Ʈ��');
Insert into SCOTT.COMPUTER (NAME,CPU,MAINBOARD,MEMORY,GPU,POWER,SSDHDD,OPT) values ('��׿� 13��','i7-10700','b460','16g','rtx3070','700w','ssd-500g','��Ʈ��');
Insert into SCOTT.COMPUTER (NAME,CPU,MAINBOARD,MEMORY,GPU,POWER,SSDHDD,OPT) values ('�ݿɿ� 2��','r5-3500x','a320','16g','gtx1650','500w','ssd-500g','����');
Insert into SCOTT.COMPUTER (NAME,CPU,MAINBOARD,MEMORY,GPU,POWER,SSDHDD,OPT) values ('�ݿɿ� 3��','i5-10400f','h410','16g','gtx1650','500w','ssd-500g','����');
Insert into SCOTT.COMPUTER (NAME,CPU,MAINBOARD,MEMORY,GPU,POWER,SSDHDD,OPT) values ('�ݿɿ� 4��','i5-10400','h410','16g','gtx1650','500w','ssd-500g','����');
Insert into SCOTT.COMPUTER (NAME,CPU,MAINBOARD,MEMORY,GPU,POWER,SSDHDD,OPT) values ('�ݿɿ� 1��','i5-9400f','h310','16g','gtx1650','500w','ssd-500g','����');
Insert into SCOTT.COMPUTER (NAME,CPU,MAINBOARD,MEMORY,GPU,POWER,SSDHDD,OPT) values ('�ݿɿ� 6��','i5-10400f','h410','16g','gtx1660','600w','ssd-500g','ǥ��');
Insert into SCOTT.COMPUTER (NAME,CPU,MAINBOARD,MEMORY,GPU,POWER,SSDHDD,OPT) values ('�ݿɿ� 5��','r5-3500','a320','16g','gtx1660','600w','ssd-500g','ǥ��');
Insert into SCOTT.COMPUTER (NAME,CPU,MAINBOARD,MEMORY,GPU,POWER,SSDHDD,OPT) values ('�ݿɿ� 7��','i5-10400','h410','16g','gtx1660','600w','ssd-500g','ǥ��');
Insert into SCOTT.COMPUTER (NAME,CPU,MAINBOARD,MEMORY,GPU,POWER,SSDHDD,OPT) values ('�ݿɿ� 9��','r5-5600x','a520','16g','gtx1660','600w','ssd-500g','ǥ��');
Insert into SCOTT.COMPUTER (NAME,CPU,MAINBOARD,MEMORY,GPU,POWER,SSDHDD,OPT) values ('�ݿɿ� 8��','i7-10700f','h410','16g','rtx2060','600w','ssd-500g','����');
Insert into SCOTT.COMPUTER (NAME,CPU,MAINBOARD,MEMORY,GPU,POWER,SSDHDD,OPT) values ('�ݿɿ� 10��','i5-10700f','h410','16g','rtx2060','600w','ssd-500g','����');
Insert into SCOTT.COMPUTER (NAME,CPU,MAINBOARD,MEMORY,GPU,POWER,SSDHDD,OPT) values ('�ݿɿ� 11��','r7-3700x','a320m-k','16g','rtx2060','700w','ssd-500g','����');
Insert into SCOTT.COMPUTER (NAME,CPU,MAINBOARD,MEMORY,GPU,POWER,SSDHDD,OPT) values ('�ݿɿ� 12��','r7-5800x','a520','16g','rtx2060','600w','ssd-500g','����');
Insert into SCOTT.COMPUTER (NAME,CPU,MAINBOARD,MEMORY,GPU,POWER,SSDHDD,OPT) values ('�ѿ� 1��','i3-10100f','h410mh6-m7','4g','gt710','500w','ssd-256g','�Ϲ�');
Insert into SCOTT.COMPUTER (NAME,CPU,MAINBOARD,MEMORY,GPU,POWER,SSDHDD,OPT) values ('�ѿ� 2��','i3-10100f','h410mh','4g','gt1030','500w','ssd-256g','�Ϲ�');
Insert into SCOTT.COMPUTER (NAME,CPU,MAINBOARD,MEMORY,GPU,POWER,SSDHDD,OPT) values ('�ѿ� 3��','r3-3100','a320am4-m3d','8g','gtx1650','500w','ssd-240g','�߱�');
Insert into SCOTT.COMPUTER (NAME,CPU,MAINBOARD,MEMORY,GPU,POWER,SSDHDD,OPT) values ('�ѿ� 5��','i3-10100f','h410mh','8g','gtx1650','500w','ssd-512g','�߱�');
Insert into SCOTT.COMPUTER (NAME,CPU,MAINBOARD,MEMORY,GPU,POWER,SSDHDD,OPT) values ('�ѿ� 6��','r5-3500','a320m','8g','gtx1650','500w','ssd-256g','�߱�');
Insert into SCOTT.COMPUTER (NAME,CPU,MAINBOARD,MEMORY,GPU,POWER,SSDHDD,OPT) values ('�ѿ� 4��','i3-10100f','h410mh','8g','gtx1650','500w','ssd-128g','�߱�');
Insert into SCOTT.COMPUTER (NAME,CPU,MAINBOARD,MEMORY,GPU,POWER,SSDHDD,OPT) values ('�ѿ� 7��','i5-9400f','h320m','8g','gtx1650','600w','ssd-128g','Ǯ��');
Insert into SCOTT.COMPUTER (NAME,CPU,MAINBOARD,MEMORY,GPU,POWER,SSDHDD,OPT) values ('�ѿ� 8��','i5-10400','h410m-e','8g','gtx1650','600w','ssd-256g','Ǯ��');
Insert into SCOTT.COMPUTER (NAME,CPU,MAINBOARD,MEMORY,GPU,POWER,SSDHDD,OPT) values ('�ѿ� 9�� ','i5-9400f','b365m','8g','gtx1660','600w','ssd-256g','Ǯ��');
Insert into SCOTT.COMPUTER (NAME,CPU,MAINBOARD,MEMORY,GPU,POWER,SSDHDD,OPT) values ('�ѿ� 10��','r5-3600','b450m','8g','gtx1660','600w','ssd-256g','Ǯ��');
Insert into SCOTT.COMPUTER (NAME,CPU,MAINBOARD,MEMORY,GPU,POWER,SSDHDD,OPT) values ('�׷����۾���1','i5-10400f','h410m','8g','gtx1660','600w','ssd-128g','����');
Insert into SCOTT.COMPUTER (NAME,CPU,MAINBOARD,MEMORY,GPU,POWER,SSDHDD,OPT) values ('�׷����۾���2','i5-9400f','h310cm-dvs','8g','gtx1650','600w','ssd-512g','����');
Insert into SCOTT.COMPUTER (NAME,CPU,MAINBOARD,MEMORY,GPU,POWER,SSDHDD,OPT) values ('�׷����۾���3','i5-10400f','h410m-e','8g','gtx1650','600w','ssd-512g','����');
Insert into SCOTT.COMPUTER (NAME,CPU,MAINBOARD,MEMORY,GPU,POWER,SSDHDD,OPT) values ('�׷����۾���4','i5-9500f','h310m-c','8g','gtx1650','600w','ssd-128g','����');
Insert into SCOTT.COMPUTER (NAME,CPU,MAINBOARD,MEMORY,GPU,POWER,SSDHDD,OPT) values ('�׷����۾���5','r5-3600','b450m','8g','gtx1660','600w','ssd-256g','�߿�');
Insert into SCOTT.COMPUTER (NAME,CPU,MAINBOARD,MEMORY,GPU,POWER,SSDHDD,OPT) values ('�׷����۾���6','i7-9700','h310m-c','8g','gtx1660','600w','ssd-256g','�߿�');
Insert into SCOTT.COMPUTER (NAME,CPU,MAINBOARD,MEMORY,GPU,POWER,SSDHDD,OPT) values ('�׷����۾���7','i5-10500','b460m-a','8g','gtx1660','600w','ssd-500g','�߿�');
Insert into SCOTT.COMPUTER (NAME,CPU,MAINBOARD,MEMORY,GPU,POWER,SSDHDD,OPT) values ('�׷����۾���8','i7-10700f','h410mh','16g','gtx1660','600w','ssd-512g','�߿�');
Insert into SCOTT.COMPUTER (NAME,CPU,MAINBOARD,MEMORY,GPU,POWER,SSDHDD,OPT) values ('�׷����۾���9','r7-3800xt','x570','16g','gtx1660','600w','ssd-512g','���');
Insert into SCOTT.COMPUTER (NAME,CPU,MAINBOARD,MEMORY,GPU,POWER,SSDHDD,OPT) values ('�׷����۾���10','i9-10900f','z490-v','16g','gtx1660','600w','ssd-512g','���');
Insert into SCOTT.COMPUTER (NAME,CPU,MAINBOARD,MEMORY,GPU,POWER,SSDHDD,OPT) values ('�׷����۾���11','i7-10700kf','z490','16g','rtx2060','600w','ssd-500g','���');
Insert into SCOTT.COMPUTER (NAME,CPU,MAINBOARD,MEMORY,GPU,POWER,SSDHDD,OPT) values ('�׷����۾���12','i9-10850ka','b460m','16g','rtx2060','600w','ssd-500g','���');
Insert into SCOTT.COMPUTER (NAME,CPU,MAINBOARD,MEMORY,GPU,POWER,SSDHDD,OPT) values ('�׷����۾���13','r9-3900x','x570','16g','rtx3070','750w','ssd-256g','Ǯ��');
Insert into SCOTT.COMPUTER (NAME,CPU,MAINBOARD,MEMORY,GPU,POWER,SSDHDD,OPT) values ('�׷����۾���14','r9-3900x','x570','16g','rtx3070','750w','ssd-256g','Ǯ��');
Insert into SCOTT.COMPUTER (NAME,CPU,MAINBOARD,MEMORY,GPU,POWER,SSDHDD,OPT) values ('�׷����۾���15','i9-10900kf','z490-a','16g','rtx2060','600w','ssd-500g','Ǯ��');
Insert into SCOTT.COMPUTER (NAME,CPU,MAINBOARD,MEMORY,GPU,POWER,SSDHDD,OPT) values ('�׷����۾���16','i9-10900kf','z490-v','32g','rtx3070','850w','ssd-512g','Ǯ��');
Insert into SCOTT.COMPUTER (NAME,CPU,MAINBOARD,MEMORY,GPU,POWER,SSDHDD,OPT) values ('�ѿ� 15��','�ڸ�-g6400','h410mh','4g','gt1030','500w','ssd-128g','�Ϲ�');
Insert into SCOTT.COMPUTER (NAME,CPU,MAINBOARD,MEMORY,GPU,POWER,SSDHDD,OPT) values ('�ѿ� 14��','Ŀ�Ƿ���ũ-g5420','h310m','4g','gt1030','500w','ssd-256g','�Ϲ�');
--------------------------------------------------------
--  DDL for Index SYS_C0012025
--------------------------------------------------------

  CREATE UNIQUE INDEX "SCOTT"."SYS_C0012025" ON "SCOTT"."COMPUTER" ("NAME") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  Constraints for Table COMPUTER
--------------------------------------------------------

  ALTER TABLE "SCOTT"."COMPUTER" MODIFY ("NAME" NOT NULL ENABLE);
 
  ALTER TABLE "SCOTT"."COMPUTER" MODIFY ("CPU" NOT NULL ENABLE);
 
  ALTER TABLE "SCOTT"."COMPUTER" MODIFY ("MAINBOARD" NOT NULL ENABLE);
 
  ALTER TABLE "SCOTT"."COMPUTER" MODIFY ("MEMORY" NOT NULL ENABLE);
 
  ALTER TABLE "SCOTT"."COMPUTER" MODIFY ("GPU" NOT NULL ENABLE);
 
  ALTER TABLE "SCOTT"."COMPUTER" MODIFY ("POWER" NOT NULL ENABLE);
 
  ALTER TABLE "SCOTT"."COMPUTER" MODIFY ("SSDHDD" NOT NULL ENABLE);
 
  ALTER TABLE "SCOTT"."COMPUTER" ADD PRIMARY KEY ("NAME")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS"  ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table COMPUTER
--------------------------------------------------------

  ALTER TABLE "SCOTT"."COMPUTER" ADD CONSTRAINT "FK_CPU" FOREIGN KEY ("CPU")
	  REFERENCES "SCOTT"."CPU" ("NAME") ENABLE;
 
  ALTER TABLE "SCOTT"."COMPUTER" ADD CONSTRAINT "FK_GPU" FOREIGN KEY ("GPU")
	  REFERENCES "SCOTT"."GPU" ("NAME") ENABLE;
 
  ALTER TABLE "SCOTT"."COMPUTER" ADD CONSTRAINT "FK_MAINBOARD" FOREIGN KEY ("MAINBOARD")
	  REFERENCES "SCOTT"."MAINBOARD" ("NAME") ENABLE;
 
  ALTER TABLE "SCOTT"."COMPUTER" ADD CONSTRAINT "FK_MEMORY" FOREIGN KEY ("MEMORY")
	  REFERENCES "SCOTT"."MEMORY" ("NAME") ENABLE;
 
  ALTER TABLE "SCOTT"."COMPUTER" ADD CONSTRAINT "FK_POWER" FOREIGN KEY ("POWER")
	  REFERENCES "SCOTT"."POWER" ("NAME") ENABLE;
 
  ALTER TABLE "SCOTT"."COMPUTER" ADD CONSTRAINT "FK_SSDHDD" FOREIGN KEY ("SSDHDD")
	  REFERENCES "SCOTT"."SSDHDD" ("NAME") ENABLE;
